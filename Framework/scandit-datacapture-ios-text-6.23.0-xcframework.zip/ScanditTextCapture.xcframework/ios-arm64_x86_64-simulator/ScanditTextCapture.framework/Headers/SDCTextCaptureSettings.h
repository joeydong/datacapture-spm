/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCDirection.h>

@protocol SDCLocationSelection;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.1.0
 *
 * Loads the text capture configuration and holds all the text recognition related settings, such as text selection area. To use the settings, use them when creating a text capture instance.
 */
NS_SWIFT_NAME(TextCaptureSettings)
SDC_EXPORTED_SYMBOL
@interface SDCTextCaptureSettings : NSObject <NSCopying>

/**
 * Added in version 6.1.0
 *
 * Defines the strategy with which to select one out of many visible texts. See Scan Area Guide. By default, this property is nil and text selection is disabled.
 *
 * Currently only SDCRectangularLocationSelection is supported.
 */
@property (nonatomic, strong, nullable) id<SDCLocationSelection> locationSelection;
/**
 * Added in version 6.1.0
 *
 * The recognition direction tells text capture in what direction text is expected.
 */
@property (nonatomic, assign) SDCDirection recognitionDirection;
/**
 * Added in version 6.1.0
 *
 * Determines the time interval in which captured texts with the same value are filtered out as duplicates. By default, when the same text is captured in consecutive frames, it is reported again as a new recognition. Use this property to change the interval or completely turn off duplicate filtering:
 *
 *   • Setting this property to value smaller than zero, means that the same text will not be reported again until the capturing session has been stopped.
 *
 *   • Setting this property to a value of zero means that the same text will be reported every time it is found.
 *
 *   • Setting this property to a value larger than zero indicates the time that must pass between the same text to be reported again.
 */
@property (nonatomic, assign) NSTimeInterval duplicateFilter;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Added in version 6.1.0
 *
 * Construct a new text capture settings with the provided configuration file. The file contains the necessary configuration for the text capture back-end.
 */
+ (nullable instancetype)settingsWithContentsOfURL:(nonnull NSURL *)URL
                                             error:(NSError *_Nullable *_Nullable)error
    NS_SWIFT_UNAVAILABLE("Use initializer instead");
/**
 * Added in version 6.1.0
 *
 * Construct a new text capture settings with the provided JSON string. The JSON contains the necessary configuration for the text capture back-end.
 *
 * In case of failure this method will return nil and error will contain the failure reason.
 *
 * For details about the format of the JSON check Text Capture Settings JSON Structure.
 */
+ (nullable instancetype)settingsFromJSONString:(nonnull NSString *)JSONString
                                          error:(NSError *_Nullable *_Nullable)error
    NS_SWIFT_NAME(init(jsonString:));
/**
 * Added in version 6.3.0
 *
 * Updates the settings according to a JSON serialization. See Serialization for details.
 */
- (BOOL)updateFromJSONString:(nonnull NSString *)JSONString
                       error:(NSError *_Nullable *_Nullable)error;

/**
 * Added in version 6.14.0
 *
 * Construct a new text capture settings with the provided configuration file. The file contains the necessary configuration for the text capture back-end.
 */
- (nullable instancetype)initWithContentsOfURL:(nonnull NSURL *)URL
                                         error:(NSError *_Nullable *_Nullable)error;

/**
 * Added in version 6.3.0
 *
 * Sets a property to the provided value. Use this method to set properties that are not yet part of a stable API. Properties set through this method may change in a future release.
 */
- (void)setValue:(nullable id)value
     forProperty:(nonnull NSString *)property NS_SWIFT_NAME(set(value:forProperty:));
/**
 * Added in version 6.3.0
 *
 * Retrieves the value of a previously set property. In case the property does not exist, nil is returned. Use this method to get properties that are not yet part of a stable API. These properties may change in a future release.
 */
- (nullable id)valueForProperty:(nonnull NSString *)property;

@end

NS_ASSUME_NONNULL_END
