/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>

@class SDCFeedback;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.1.0
 *
 * Determines what feedback (vibration, sound) should be emitted when reading text.
 * The feedback is specified for each SDCTextCapture instance separately and can be changed
 * through the feedback property by either modifying an existing
 * instance of SDCTextCaptureFeedback, or assigning a new one.
 *
 * As of now, this class only allows to configure the feedback that gets emitted when a text is read successfully, through the success property.
 *
 * See documentation on the SDCTextCapture.feedback property for usage samples.
 */
NS_SWIFT_NAME(TextCaptureFeedback)
SDC_EXPORTED_SYMBOL
@interface SDCTextCaptureFeedback : NSObject

/**
 * Added in version 6.1.0
 *
 * Returns a text capture feedback with default configuration:
 *
 *   • default beep sound is loaded,
 *
 *   • beeping for the success event is enabled,
 *
 *   • vibration for the success event is enabled.
 */
@property (class, nonatomic, readonly) SDCTextCaptureFeedback *defaultFeedback;
/**
 * Added in version 6.1.0
 *
 * A feedback for a success event.
 */
@property (nonatomic, strong, nonnull) SDCFeedback *success;
/**
 * Added in version 6.9.0
 *
 * Returns the JSON representation of the feedback.
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

/**
 * Added in version 6.3.0
 *
 * Construct a new text capture feedback with the provided JSON serialization. See Serialization for details.
 */
+ (nullable instancetype)textCaptureFeedbackFromJSONString:(nonnull NSString *)JSONString
                                                     error:(NSError *_Nullable *_Nullable)error;
@end

NS_ASSUME_NONNULL_END
