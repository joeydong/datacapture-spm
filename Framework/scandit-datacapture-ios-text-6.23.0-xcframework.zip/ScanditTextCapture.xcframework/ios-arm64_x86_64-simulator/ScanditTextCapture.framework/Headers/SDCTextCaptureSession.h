/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>

@class SDCCapturedText;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.1.0
 *
 * The text capture session is responsible for determining the list of relevant texts by filtering out duplicates. This filtering of duplicates is completely time-based and doesn’t use any information about the location of the text. By default, all the texts captured in a frame are always reported. It is possible to filter out texts recently captured by changing SDCTextCaptureSettings.duplicateFilter.
 *
 * When the text capture mode is disabled, the session’s duplicate filter is reset.
 *
 * The tracking session should only be accessed from within textCapture:didCaptureInSession:frameData: to which it is provided as an argument. It is not safe to be accessed from anywhere else since it may be concurrently modified.
 *
 * Specifically no reference to newlyCapturedTexts should be kept and traversed outside of textCapture:didCaptureInSession:frameData:. Instead a copy of the list should be made to avoid concurrent modification. The individual captured texts can be referenced without copying as they are not further modified.
 */
NS_SWIFT_NAME(TextCaptureSession)
SDC_EXPORTED_SYMBOL
@interface SDCTextCaptureSession : NSObject

/**
 * Added in version 6.1.0
 *
 * List of texts that were newly captured in the last processed frame.
 */
@property (nonatomic, nonnull, readonly) NSArray<SDCCapturedText *> *newlyCapturedTexts;
/**
 * Added in version 6.1.0
 *
 * The identifier of the current frame sequence.
 *
 * As long as there is no interruptions of frames coming from the camera, the frameSequenceId will stay the same.
 */
@property (nonatomic, readonly) NSInteger frameSequenceId;
/**
 * Added in version 6.4.0
 *
 * Returns the JSON representation of the text capture session.
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
