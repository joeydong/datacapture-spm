/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCDataCaptureModeDeserializer.h>

@class SDCJSONValue;
@class SDCTextCapture;
@class SDCTextCaptureDeserializer;
@class SDCTextCaptureSettings;
@class SDCTextCaptureOverlay;
@class SDCDataCaptureContext;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.3.0
 *
 * The listener for the text capture deserializer.
 */
NS_SWIFT_NAME(TextCaptureDeserializerDelegate)
@protocol SDCTextCaptureDeserializerDelegate <NSObject>

/**
 * Added in version 6.3.0
 *
 * Called before the deserialization of text capture started. This is the point to overwrite defaults before the deserialization is performed.
 */
- (void)textCaptureDeserializer:(SDCTextCaptureDeserializer *)deserializer
      didStartDeserializingMode:(SDCTextCapture *)mode
                  fromJSONValue:(SDCJSONValue *)JSONValue;
/**
 * Added in version 6.3.0
 *
 * Called when the deserialization of text capture finished. This is the point to do additional deserialization.
 */
- (void)textCaptureDeserializer:(SDCTextCaptureDeserializer *)deserializer
     didFinishDeserializingMode:(SDCTextCapture *)mode
                  fromJSONValue:(SDCJSONValue *)JSONValue;

/**
 * Added in version 6.3.0
 *
 * Called before the deserialization of the text capture settings started. This is the point to overwrite defaults before the deserialization is performed.
 */
- (void)textCaptureDeserializer:(SDCTextCaptureDeserializer *)deserializer
    didStartDeserializingSettings:(SDCTextCaptureSettings *)settings
                    fromJSONValue:(SDCJSONValue *)JSONValue;
/**
 * Added in version 6.3.0
 *
 * Called when the deserialization of the text capture settings finished. This is the point to do additional deserialization.
 */
- (void)textCaptureDeserializer:(SDCTextCaptureDeserializer *)deserializer
    didFinishDeserializingSettings:(SDCTextCaptureSettings *)settings
                     fromJSONValue:(SDCJSONValue *)JSONValue;

/**
 * Added in version 6.3.0
 *
 * Called before the deserialization of the text capture overlay started. This is the point to overwrite defaults before the deserialization is performed.
 */
- (void)textCaptureDeserializer:(SDCTextCaptureDeserializer *)deserializer
    didStartDeserializingOverlay:(SDCTextCaptureOverlay *)overlay
                   fromJSONValue:(SDCJSONValue *)JSONValue;
/**
 * Added in version 6.3.0
 *
 * Called when the deserialization of the text capture overlay finished. This is the point to do additional deserialization.
 */
- (void)textCaptureDeserializer:(SDCTextCaptureDeserializer *)deserializer
    didFinishDeserializingOverlay:(SDCTextCaptureOverlay *)overlay
                    fromJSONValue:(SDCJSONValue *)JSONValue;

@end

/**
 * Added in version 6.3.0
 *
 * A deserializer to construct text capture from JSON. For most use cases it is enough to use SDCTextCapture.textCaptureFromJSONString:context:error: which internally uses this deserializer. Using the deserializer gives the advantage of being able to listen to the deserialization events as they happen and potentially influence them. Additionally warnings can be read from the deserializer that would otherwise not be available.
 *
 * Related topics: Serialization.
 */
NS_SWIFT_NAME(TextCaptureDeserializer)
SDC_EXPORTED_SYMBOL
@interface SDCTextCaptureDeserializer : NSObject <SDCDataCaptureModeDeserializer>
/**
 * Added in version 6.3.0
 *
 * The object informed about deserialization events.
 */
@property (nonatomic, weak, nullable) id<SDCTextCaptureDeserializerDelegate> delegate;
/**
 * Added in version 6.3.0
 *
 * The warnings produced during deserialization, for example which properties were not used during deserialization.
 */
@property (nonatomic, readonly) NSArray<NSString *> *warnings;

/**
 * Added in version 6.3.0
 *
 * Creates a new deserializer object.
 */
+ (instancetype)textCaptureDeserializer;

/**
 * Added in version 6.3.0
 *
 * Deserializes text capture from JSON.
 *
 * An error is set if the provided JSON does not contain required properties or contains properties of the wrong type.
 */
- (nullable SDCTextCapture *)modeFromJSONString:(NSString *)JSONString
                                    withContext:(SDCDataCaptureContext *)context
                                          error:(NSError *_Nullable *_Nullable)error;
/**
 * Added in version 6.3.0
 *
 * Takes an existing text capture and updates it by deserializing new or changed properties from JSON. See Updating from JSON for details of how updates are being done.
 *
 * An error is set if the provided JSON does not contain required properties or contains properties of the wrong type.
 */
- (nullable SDCTextCapture *)updateMode:(SDCTextCapture *)textCapture
                         fromJSONString:(NSString *)JSONString
                                  error:(NSError *_Nullable *_Nullable)error;

/**
 * Added in version 6.3.0
 *
 * Deserializes text capture settings from JSON.
 *
 * An error is set if the provided JSON does not contain required properties or contains properties of the wrong type.
 */
- (nullable SDCTextCaptureSettings *)settingsFromJSONString:(NSString *)JSONString
                                                      error:(NSError *_Nullable *_Nullable)error;
/**
 * Added in version 6.3.0
 *
 * Takes existing text capture settings and updates them by deserializing new or changed properties from JSON. See Updating from JSON for details of how updates are being done.
 *
 * An error is set if the provided JSON does not contain required properties or contains properties of the wrong type.
 */
- (nullable SDCTextCaptureSettings *)updateSettings:(SDCTextCaptureSettings *)settings
                                     fromJSONString:(NSString *)JSONString
                                              error:(NSError *_Nullable *_Nullable)error;

/**
 * Added in version 6.3.0
 *
 * Deserializes a text capture overlay from JSON.
 *
 * An error is set if the provided JSON does not contain required properties or contains properties of the wrong type.
 */
- (nullable SDCTextCaptureOverlay *)overlayFromJSONString:(NSString *)JSONString
                                                 withMode:(SDCTextCapture *)mode
                                                    error:(NSError *_Nullable *_Nullable)error;
/**
 * Added in version 6.3.0
 *
 * Takes an existing text capture overlay and updates it by deserializing new or changed properties from JSON. See Updating from JSON for details of how updates are being done.
 *
 * An error is set if the provided JSON does not contain required properties or contains properties of the wrong type.
 */
- (nullable SDCTextCaptureOverlay *)updateOverlay:(SDCTextCaptureOverlay *)overlay
                                   fromJSONString:(NSString *)JSONString
                                            error:(NSError *_Nullable *_Nullable)error;

@end

NS_ASSUME_NONNULL_END
