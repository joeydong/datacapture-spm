/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double ScanditTextCaptureVersionNumber;

FOUNDATION_EXPORT const unsigned char ScanditTextCaptureVersionString[];

#import <ScanditCaptureCore/ScanditCaptureCore.h>
#import <ScanditTextCapture/SDCCapturedText.h>
#import <ScanditTextCapture/SDCTextCapture.h>
#import <ScanditTextCapture/SDCTextCaptureDeserializer.h>
#import <ScanditTextCapture/SDCTextCaptureFeedback.h>
#import <ScanditTextCapture/SDCTextCaptureOverlay.h>
#import <ScanditTextCapture/SDCTextCaptureSession.h>
#import <ScanditTextCapture/SDCTextCaptureSettings.h>

