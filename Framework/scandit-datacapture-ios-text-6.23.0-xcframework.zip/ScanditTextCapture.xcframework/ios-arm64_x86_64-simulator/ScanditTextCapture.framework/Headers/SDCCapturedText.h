/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCQuadrilateral.h>

@class SDCEncodingRange;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.1.0
 *
 * A captured text.
 *
 * SDK-11002 add link to section describing coordinate conversions.
 */
NS_SWIFT_NAME(CapturedText)
SDC_EXPORTED_SYMBOL
@interface SDCCapturedText : NSObject

/**
 * Added in version 6.1.0
 *
 * The value of the captured text.
 */
@property (nonatomic, nonnull, readonly) NSString *value;
/**
 * Added in version 6.1.0
 *
 * The location of the captured text. The coordinates are in image-space, meaning that the coordinates correspond to actual pixels in the image. For display, the coordinates need first to be converted into screen-space.
 *
 * The meaning of the values of SDCQuadrilateral.topLeft etc is such that the top left point corresponds to the top left corner of the captured text, independent of how the captured text is oriented in the image.
 */
@property (nonatomic, readonly) SDCQuadrilateral location;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
