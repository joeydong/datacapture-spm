/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCDataCaptureMode.h>
#import <ScanditCaptureCore/SDCMeasureUnit.h>

@class SDCTextCapture;
@class SDCTextCaptureSession;
@class SDCTextCaptureSettings;
@class SDCDataCaptureContext;
@class SDCTextCaptureFeedback;
@class SDCCameraSettings;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.1.0
 *
 * Delegate protocol for traditional text capture.
 */
NS_SWIFT_NAME(TextCaptureListener)
@protocol SDCTextCaptureListener <NSObject>

@required

/**
 * Added in version 6.1.0
 *
 * Invoked whenever at least one text has been captured. The newly captured texts can be retrieved from SDCTextCaptureSession.newlyCapturedTexts.
 *
 * This method is invoked from a recognition internal thread. To perform UI work, you must dispatch to the main thread first.
 *
 * Inside this method, you will typically want to start processing the captured texts somehow, e.g. by validating the text captured. Depending on the application, you will want to pause, or stop recognition, or continue reading texts:
 *
 *   • To pause the capture session, but keep the camera (frame source) running, just set the text capture’s enabled property to NO.
 *
 * captureMode.isEnabled = true
 *
 *   • To stop the capture session, you will need to both disable the capture mode and stop the frame source. While it is possible to only stop the camera and keep the capture mode enabled, this may lead to additional capture events being delivered, which is typically not desired. The following lines of code show how to disable the capture mode and stop the frame source as well:
 *
 * // no more didCapture callbacks will be invoked after this call.
 * captureMode.isEnabled = false
 * // asynchronously turn off the camera as quickly as possible.
 * captureMode.context?.frameSource?.switch(toDesiredState: .off, completionHandler: nil)
 *
 * @code
 * captureMode.isEnabled = true
 * @endcode
 *
 * @code
 * // no more didCapture callbacks will be invoked after this call.
 * captureMode.isEnabled = false
 * // asynchronously turn off the camera as quickly as possible.
 * captureMode.context?.frameSource?.switch(toDesiredState: .off, completionHandler: nil)
 * @endcode
 */
- (void)textCapture:(SDCTextCapture *)textCapture
    didCaptureInSession:(SDCTextCaptureSession *)session
              frameData:(id<SDCFrameData>)frameData;

@optional

/**
 * Added in version 6.1.0
 *
 * Called when the listener starts observing the text capture instance.
 */
- (void)didStartObservingTextCapture:(SDCTextCapture *)textCapture;

/**
 * Added in version 6.1.0
 *
 * Called when the listener stops observing the text capture instance.
 */
- (void)didStopObservingTextCapture:(SDCTextCapture *)textCapture;

@end

/**
 * Added in version 6.1.0
 *
 * Capture mode for reading text.
 */
NS_SWIFT_NAME(TextCapture)
SDC_EXPORTED_SYMBOL
@interface SDCTextCapture : NSObject <SDCDataCaptureMode>

/**
 * Added in version 6.1.0
 *
 * Returns the recommended camera settings for use with text capture.
 */
@property (class, nonatomic, nonnull, readonly) SDCCameraSettings *recommendedCameraSettings;
/**
 * Added in version 6.1.0
 *
 * Implemented from SDCDataCaptureMode. See SDCDataCaptureMode.enabled.
 */
@property (nonatomic, assign, getter=isEnabled) BOOL enabled;
/**
 * Added in version 6.1.0
 *
 * The point of interest overwriting the point of interest of the data capture view.
 * By default, this overwriting point of interest is not set and the one from the data capture view is used.
 *
 * Use SDCPointWithUnitNull (FloatWithUnit.null in Swift) to unset the point of interest.
 *
 * The overwriting point of interest is used to control the center of attention for the following subsystems:
 *
 *   • Location selection. When no location selection is set, the point of interest defines the location at which the recognition optimizes for reading barcodes.
 *
 *   • Rendered viewfinders.
 */
@property (nonatomic, assign) SDCPointWithUnit pointOfInterest;
/**
 * Added in version 6.1.0
 *
 * Implemented from SDCDataCaptureMode. See SDCDataCaptureMode.context.
 */
@property (nonatomic, nullable, readonly) SDCDataCaptureContext *context;
/**
 * Added in version 6.1.0
 *
 * Instance of SDCTextCaptureFeedback that is used by text capture to notify users about Success events.
 *
 * The default instance of the Feedback will have both sound and vibration enabled. A default beep sound will be used for the sound.
 *
 * To change the feedback emitted, the SDCTextCaptureFeedback can be modified as shown below, or a new one can be assigned.
 *
 * @code
 * let textCapture: TextCapture = ...
 * textCapture.feedback.success = Feedback(vibration: nil, sound: Sound.default)
 * @endcode
 */
@property (nonatomic, strong, nonnull) SDCTextCaptureFeedback *feedback;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Added in version 6.1.0
 *
 * Construct a new text capture mode with the provided context and settings. Then the context is not nil, the capture mode is automatically added to the context.
 */
+ (instancetype)textCaptureWithContext:(nullable SDCDataCaptureContext *)context
                              settings:(nonnull SDCTextCaptureSettings *)settings;

/**
 * Added in version 6.1.0
 *
 * Asynchronously apply the new settings to the text capture mode. If text capture is currently running, the task will complete when the next frame is processed, and will use the new settings for that frame. If text capture is currently not running, the task will complete as soon as the settings have been stored and won’t wait until the next frame is going to be processed.
 */
- (void)applySettings:(nonnull SDCTextCaptureSettings *)settings
    completionHandler:(nullable void (^)(void))completionHandler;

/**
 * Added in version 6.1.0
 *
 * Add the listener to observe this text capture instance.
 *
 * In case the same listener is already observing this instance, calling this method will not add the listener again. The listener is stored using a weak reference and must thus be retained by the caller for it to not go out of scope.
 */
- (void)addListener:(nonnull id<SDCTextCaptureListener>)listener NS_SWIFT_NAME(addListener(_:));

/**
 * Added in version 6.1.0
 *
 * Remove a previously added listener from this text capture instance.
 *
 * In case the listener is not currently observing this instance, calling this method has no effect.
 */
- (void)removeListener:(nonnull id<SDCTextCaptureListener>)listener
    NS_SWIFT_NAME(removeListener(_:));

/**
 * Added in version 6.3.0
 *
 * Construct a new text capture mode with the provided JSON serialization. See Serialization for details. The capture mode is automatically added to the context.
 */
+ (nullable instancetype)textCaptureFromJSONString:(nonnull NSString *)JSONString
                                           context:(nonnull SDCDataCaptureContext *)context
                                             error:(NSError *_Nullable *_Nullable)error
    NS_SWIFT_NAME(init(jsonString:context:));

/**
 * Added in version 6.3.0
 *
 * Updates the mode according to a JSON serialization. See Serialization for details.
 */
- (BOOL)updateFromJSONString:(nonnull NSString *)JSONString
                       error:(NSError *_Nullable *_Nullable)error;
@end

NS_ASSUME_NONNULL_END
