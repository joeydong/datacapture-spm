/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCDataCaptureOverlay.h>

@class SDCTextCapture;
@class SDCBrush;
@class SDCDataCaptureView;
@protocol SDCViewfinder;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.1.0
 *
 * Overlay for the SDCTextCapture capture mode that displays the bounding boxes containing each captured text on top of the video preview. The appearance of bounding boxes can be configured or turned off completely through the brush property.
 */
NS_SWIFT_NAME(TextCaptureOverlay)
SDC_EXPORTED_SYMBOL
@interface SDCTextCaptureOverlay : NSObject <SDCDataCaptureOverlay>

/**
 * Added in version 6.1.0
 *
 * Returns the default brush used by the overlay.
 */
@property (class, nonatomic, nonnull, readonly) SDCBrush *defaultBrush;
/**
 * Added in version 6.1.0
 *
 * The brush used for visualizing a captured text in the UI. To turn off drawing of locations, set the brush to use both a transparent fill and stroke color. By default, the brush has a transparent fill color, a “Scandit”-blue stroke color, and a stroke width of 1.
 */
@property (nonatomic, strong, nonnull) SDCBrush *brush;
/**
 * Added in version 6.1.0
 *
 * Whether to show scan area guides on top of the preview. This property is useful during development to visualize the current scan areas on screen. It is not meant to be used for production. By default this property is NO.
 */
@property (nonatomic, assign) BOOL shouldShowScanAreaGuides;
/**
 * Added in version 6.1.0
 *
 * Set the viewfinder. By default, the viewfinder is nil. Set this to an instance of SDCViewfinder if you want to draw a viewfinder.
 */
@property (nonatomic, strong, nullable) id<SDCViewfinder> viewfinder;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Added in version 6.1.0
 *
 * Construct a new text capture overlay for the provided text capture instance. For the overlay to be displayed on screen, it must be added to a SDCDataCaptureView.
 */
+ (instancetype)overlayWithTextCapture:(nonnull SDCTextCapture *)textCapture;
/**
 * Added in version 6.1.0
 *
 * Constructs a new text capture overlay for the provided text capture instance. When passing a non-nil view instance, the overlay is automatically added to the view.
 */
+ (instancetype)overlayWithTextCapture:(nonnull SDCTextCapture *)textCapture
                    forDataCaptureView:(nullable SDCDataCaptureView *)view
    NS_SWIFT_NAME(init(textCapture:view:));

@end

NS_ASSUME_NONNULL_END
