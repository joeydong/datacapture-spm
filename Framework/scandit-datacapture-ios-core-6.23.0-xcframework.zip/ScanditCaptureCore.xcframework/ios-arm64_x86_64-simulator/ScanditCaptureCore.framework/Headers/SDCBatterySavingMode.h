/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIView.h>
#import <ScanditCaptureCore/SDCBase.h>

/**
 * Added in version 6.20.0
 *
 * Possible values for battery saving options
 */
typedef NS_CLOSED_ENUM(NSUInteger, SDCBatterySavingMode) {
/**
     * Added in version 6.20.0
     *
     * Automatic battery saving, based on phone temperature and battery level.
     */
    SDCBatterySavingModeAuto = 0,
/**
     * Added in version 6.20.0
     *
     * Battery saving off, optimized for a faster scanning experience.
     */
    SDCBatterySavingModeOff = 1,
/**
     * Added in version 6.20.0
     *
     * Battery saving on, optimized for longer scanning sessions.
     */
    SDCBatterySavingModeOn = 2,
} NS_SWIFT_NAME(BatterySavingMode);

/**
 * Added in version 6.21.0
 */
SDC_EXTERN NSString *_Nonnull NSStringFromBatterySavingMode(SDCBatterySavingMode mode)
    NS_SWIFT_NAME(getter:SDCBatterySavingMode.jsonString(self:));
/**
 * Added in version 6.21.0
 */
SDC_EXTERN BOOL SDCBatterySavingModeFromJSONString(NSString *_Nonnull JSONString,
                                                   SDCBatterySavingMode *_Nonnull mode);
