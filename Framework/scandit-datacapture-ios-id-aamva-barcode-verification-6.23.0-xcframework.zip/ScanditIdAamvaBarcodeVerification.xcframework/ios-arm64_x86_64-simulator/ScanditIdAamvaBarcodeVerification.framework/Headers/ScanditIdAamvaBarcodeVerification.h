/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double ScanditIdAamvaBarcodeVerificationVersionNumber;

FOUNDATION_EXPORT const unsigned char ScanditIdAamvaBarcodeVerificationVersionString[];

#import <ScanditCaptureCore/ScanditCaptureCore.h>

