/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/SDCBase.h>

/**
 * Added in version 6.18.0
 *
 * The result of a comparison done by SDCVizMrzComparisonVerifier of a single piece of data from a personal identification document with a VIZ and an MRZ.
 */
typedef NS_CLOSED_ENUM(NSInteger, SDCVizMrzComparisonCheckResult) {
/**
     * Added in version 6.18.0
     *
     * The compared data matches. In some instances the check may permit minor data divergence, to compensate, for example, for a single character misread by OCR.
     */
    SDCVizMrzComparisonCheckResultPassed,
/**
     * Added in version 6.18.0
     *
     * Some suspicious differences detected. This doesn’t automatically mean that the document is fraudulent, but such document should be inspected more carefully.
     */
    SDCVizMrzComparisonCheckResultFailed,
/**
     * Added in version 6.18.0
     *
     * The data necessary to perform the check is missing and thus it is skipped.
     */
    SDCVizMrzComparisonCheckResultSkipped,
} NS_SWIFT_NAME(VizMrzComparisonCheckResult);
