/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.5.0
 *
 * The ID Capture mode supports all versions of Machine Readable Travel Documents (MRTD) specified by the International Civil Aviation Organization (ICAO).
 * The ICAO specifies four types of MRTDs:
 *
 *   • TD1 - ID cards (id cards)
 *
 *   • TD2 - other official travel documents (other official travel documents)
 *
 *   • TD3/MRP - passports (passports)
 *
 *   • MRV (A & B type) - visas (visas)
 *
 * In addition, the ID Capture mode supports the following non-ICAO standards:
 *
 *   • SwissDL - Swiss driving license (Swiss driving license)
 *
 *   • TD2/FrenchID - French ID (French identity card)
 *
 * Use the following regex pattern to filter out MRTD codes:
 *
 * Type
 *
 * Regex
 *
 * TD1 Regex Pattern
 *
 * ([A-Z0-9<]{30}\n?){3}
 *
 * TD2 Regex Pattern
 *
 * ([A-Z0-9<]{36}\n?){2}
 *
 * TD2 French Regex Pattern
 *
 * Same as TD2 Regex Pattern
 *
 * TD3 Regex Pattern
 *
 * ([A-Z0-9<]{44}\n?){2}
 *
 * MRV_A Regex Pattern
 *
 * Same as TD2 Regex Pattern
 *
 * MRV_B Regex Pattern
 *
 * Same as TD3 Regex Pattern
 *
 * Swiss Driving License Regex Pattern
 *
 * [A-Z0-9<]{9}\n([A-Z0-9<]{30}\n?){2}
 */
NS_SWIFT_NAME(MrzResult)
SDC_EXPORTED_SYMBOL
@interface SDCMrzResult : NSObject

/**
 * Added in version 6.5.0
 *
 * The document type code. One of the following values:
 *
 *   • P[passport type id] - indicates a passport,
 *
 *   • ID - indicates an id card,
 *
 *   • CA - indicates a Canada permanent resident card.
 */
@property (nonatomic, nonnull, readonly) NSString *documentCode;
/**
 * Added in version 6.5.0
 *
 * Indicates whether first or last name is truncated. For more information please refer to the official
 * specification.
 */
@property (nonatomic, readonly) BOOL namesAreTruncated;
/**
 * Added in version 6.5.0
 *
 * An optional field, for use of the issuing country or the organization.
 */
@property (nonatomic, nullable, readonly) NSString *optional;
/**
 * Added in version 6.5.0
 *
 * An optional field, for use of the issuing country or the organization.
 *
 * If SDCIdCaptureSettings.anonymizationMode is enabled for the field results, the returned value might be nil for certain documents.
 */
@property (nonatomic, nullable, readonly) NSString *optional1;
/**
 * Added in version 6.8.0
 *
 * The full MRZ text as it appears on a document.
 *
 * If SDCIdCaptureSettings.anonymizationMode is enabled for the field results, the returned value might be nil for certain documents.
 */
@property (nonatomic, nonnull, readonly) NSString *capturedMrz;
/**
 * Added in version 6.6.0
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
