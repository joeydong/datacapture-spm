/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>

@class SDCVizMrzStringComparisonCheck;
@class SDCVizMrzDateComparisonCheck;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.18.0
 *
 * The result of a personal identification document with a VIZ and an MRZ verification conducted by SDCVizMrzComparisonVerifier.
 */
NS_SWIFT_NAME(VizMrzComparisonResult)
SDC_EXPORTED_SYMBOL
@interface SDCVizMrzComparisonResult : NSObject

/**
 * Added in version 6.18.0
 *
 * Whether all the checks conducted by the verifier passed. Only the check that were run count, so YES is returned even if some of the checks were skipped.
 */
@property (nonatomic, readonly) BOOL checksPassed;
/**
 * Added in version 6.18.0
 *
 * The human-readable result of the verification.
 */
@property (nonatomic, nonnull, readonly) NSString *resultDescription;
/**
 * Added in version 6.18.0
 *
 * Whether the holder’s full names extracted from both sources of the data match. This check may permit minor data divergence, to compensate, for example, for a single character misread by OCR.
 */
@property (nonatomic, readonly) SDCVizMrzStringComparisonCheck *fullNamesMatch;
/**
 * Added in version 6.18.0
 *
 * Whether the document numbers extracted from both sources of the data match. This check may permit minor data divergence, to compensate, for example, for a single character misread by OCR.
 */
@property (nonatomic, readonly) SDCVizMrzStringComparisonCheck *documentNumbersMatch;
/**
 * Added in version 6.18.0
 *
 * Whether the holder’s dates of birth extracted from both sources of the data are the same.
 */
@property (nonatomic, readonly) SDCVizMrzDateComparisonCheck *datesOfBirthMatch;
/**
 * Added in version 6.18.0
 *
 * Whether the document’s dates of expiry extracted from both sources of the data are the same.
 */
@property (nonatomic, readonly) SDCVizMrzDateComparisonCheck *datesOfExpirationMatch;
/**
 * Added in version 6.18.0
 *
 * Whether the issuing countries extracted from both sources of the data are the same.
 */
@property (nonatomic, readonly) SDCVizMrzStringComparisonCheck *issuingCountryISOMatch;
/**
 * Added in version 6.18.0
 *
 * Returns the JSON representation of this object.
 */
@property (nonatomic, readonly) NSString *JSONString;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end
NS_ASSUME_NONNULL_END
