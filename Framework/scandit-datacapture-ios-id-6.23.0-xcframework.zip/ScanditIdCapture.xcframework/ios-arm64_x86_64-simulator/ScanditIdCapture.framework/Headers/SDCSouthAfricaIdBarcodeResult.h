/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.8.0
 *
 * Information obtained from the PDF417 barcode present on the back of a South Africa Smart ID Card.
 */
NS_SWIFT_NAME(SouthAfricaIdBarcodeResult)
SDC_EXPORTED_SYMBOL
@interface SDCSouthAfricaIdBarcodeResult : NSObject

/**
 * Added in version 6.8.0
 *
 * The three-letter country code (ISO 3166-1) of the holder’s country of birth.
 */
@property (nonatomic, nonnull, readonly) NSString *countryOfBirthISO;
/**
 * Added in version 6.8.0
 *
 * The human-readable name of the holder’s country of birth.
 */
@property (nonatomic, nonnull, readonly) NSString *countryOfBirth;
/**
 * Added in version 6.8.0
 *
 * Whether the holder is a citizen or a permanent resident.
 */
@property (nonatomic, nonnull, readonly) NSString *citizenshipStatus;
/**
 * Added in version 6.8.0
 *
 * The personal ID number of the card’s holder.
 */
@property (nonatomic, nonnull, readonly) NSString *personalIdNumber;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
