/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>
#import <ScanditIdCapture/SDCComparisonCheck.h>

@class SDCDateResult;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.11.0
 *
 * The result of the comparison of a SDCDateResult field performed by SDCAAMVAVizBarcodeComparisonVerifier. Check SDCComparisonCheck for more informations.
 */
NS_SWIFT_NAME(DateComparisonCheck)
SDC_EXPORTED_SYMBOL
@interface SDCDateComparisonCheck : NSObject <SDCComparisonCheck>

/**
 * Added in version 6.11.0
 *
 * The SDCDateResult field extracted from a human-readable front side of an AAMVA-compliant personal identification document.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *vizValue;
/**
 * Added in version 6.11.0
 *
 * The SDCDateResult field extracted from a barcode present at the back side of an AAMVA-compliant personal identification document.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *aamvaBarcodeValue;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
