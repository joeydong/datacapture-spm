/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.8.0
 *
 * Information obtained from the PDF417 barcode present on the back of a Colombia ID (Cédula de Ciudadanía) specific to this kind of document.
 */
NS_SWIFT_NAME(ColombiaIdBarcodeResult)
SDC_EXPORTED_SYMBOL
@interface SDCColombiaIdBarcodeResult : NSObject

/**
 * Added in version 6.8.0
 *
 * The blood type of the holder in the Rh system (A+, A-, B+, B-, O+, O-, AB+ or AB-).
 */
@property (nonatomic, nonnull, readonly) NSString *bloodType;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
