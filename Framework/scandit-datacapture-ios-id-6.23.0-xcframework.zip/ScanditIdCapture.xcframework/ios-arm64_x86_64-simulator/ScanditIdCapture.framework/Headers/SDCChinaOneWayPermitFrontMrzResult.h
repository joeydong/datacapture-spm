/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.16.0
 *
 * Information obtained from the Machine Readable Zone (MRZ) present on the front of a One-Way Permit to Hong Kong/Macau issued by the People’s Republic of China.
 */
NS_SWIFT_NAME(ChinaOneWayPermitFrontMrzResult)
SDC_EXPORTED_SYMBOL
@interface SDCChinaOneWayPermitFrontMrzResult : NSObject

/**
 * Added in version 6.16.0
 *
 * The document type code. Always “Q”.
 */
@property (nonatomic, nonnull, readonly) NSString *documentCode;
/**
 * Added in version 6.16.0
 *
 * The full MRZ text as it appears on a document.
 */
@property (nonatomic, nonnull, readonly) NSString *capturedMrz;
/**
 * Added in version 6.16.0
 *
 * The holder’s name in Simplified Chinese characters.
 */
@property (nonatomic, nonnull, readonly) NSString *fullNameSimplifiedChinese;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end
NS_ASSUME_NONNULL_END
