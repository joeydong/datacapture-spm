/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.13.0
 *
 * Information obtained from the PDF417 barcode present on the back of a Colombia Driver’s License (Licencia de Conducción) specific to this kind of document.
 */
NS_SWIFT_NAME(ColombiaDlBarcodeResult)
SDC_EXPORTED_SYMBOL
@interface SDCColombiaDlBarcodeResult : NSObject

/**
 * Added in version 6.13.0
 */
@property (nonatomic, nonnull, readonly) NSArray<NSString *> *categories;
/**
 * Added in version 6.13.0
 *
 * Indicates the identification type of the driver’s license.
 */
@property (nonatomic, nonnull, readonly) NSString *identificationType;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
