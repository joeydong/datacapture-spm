/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditIdCapture/SDCDateResult.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.18.0
 *
 * Information extracted from the US Visa.
 */
NS_SWIFT_NAME(UsVisaVizResult)
SDC_EXPORTED_SYMBOL
@interface SDCUsVisaVizResult : NSObject

/**
 * Added in version 6.18.0
 *
 * The visa number of the document holder.
 */
@property (nonatomic, nonnull, readonly) NSString *visaNumber;
/**
 * Added in version 6.18.0
 *
 * The passport number of the document holder.
 */
@property (nonatomic, nonnull, readonly) NSString *passportNumber;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
