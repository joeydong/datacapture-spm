/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.14.0
 *
 * Information obtained from the Machine Readable Zone (MRZ) present on the back of a Chinese Mainland Travel permit. The supported Chinese Mainland Travel Permits are listed below:
 * * Mainland Travel Permit for Hong Kong & Macau Residents
 * * Mainland Travel Permit for Taiwan Residents
 */
NS_SWIFT_NAME(ChinaMainlandTravelPermitMrzResult)
SDC_EXPORTED_SYMBOL
@interface SDCChinaMainlandTravelPermitMrzResult : NSObject

/**
 * Added in version 6.14.0
 *
 * The document type code. One of the following values:
 *
 *   • CR - indicates a Mainland Travel Permit for Hong Kong & Macau Residents.
 *
 *   • CT - indicates a Mainland Travel Permit for Taiwan Residents.
 */
@property (nonatomic, nonnull, readonly) NSString *documentCode;
/**
 * Added in version 6.14.0
 *
 * The full MRZ text as it appears on a document.
 */
@property (nonatomic, nonnull, readonly) NSString *capturedMrz;
/**
 * Added in version 6.14.0
 *
 * The personal ID Number of the document holder.
 */
@property (nonatomic, nonnull, readonly) NSString *personalIdNumber;
/**
 * Added in version 6.14.0
 *
 * The number of times the document has been renewed.
 */
@property (nonatomic, readonly) NSInteger renewalTimes;
/**
 * Added in version 6.16.0
 *
 * The holder’s name in Simplified Chinese characters.
 */
@property (nonatomic, nonnull, readonly) NSString *fullNameSimplifiedChinese;
/**
 * Added in version 6.14.0
 *
 * The number of Chinese characters omitted in in GBK (a character encoding for Simplified Chinese characters used in the People’s Republic of China) name.
 */
@property (nonatomic, readonly) NSInteger omittedCharacterCountInGBKName;
/**
 * Added in version 6.14.0
 *
 * The number of names that couldn’t be displayed in the MRZ.
 */
@property (nonatomic, readonly) NSInteger omittedNameCount;
/**
 * Added in version 6.14.0
 *
 * The code of the authority that issued this document.
 */
@property (nonatomic, nullable, readonly) NSString *issuingAuthorityCode;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
