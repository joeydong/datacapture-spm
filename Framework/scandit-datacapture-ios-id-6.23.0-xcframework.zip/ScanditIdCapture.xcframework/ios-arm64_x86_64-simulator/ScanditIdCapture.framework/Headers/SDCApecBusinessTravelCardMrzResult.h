/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCDateResult;

/**
 * Added in version 6.16.0
 *
 * Information obtained from the Machine Readable Zone (MRZ) present on the back of an APEC (Asia-Pacific Economic Cooperation) Business Travel Card.
 */
NS_SWIFT_NAME(ApecBusinessTravelCardMrzResult)
SDC_EXPORTED_SYMBOL
@interface SDCApecBusinessTravelCardMrzResult : NSObject

/**
 * Added in version 6.16.0
 *
 * The document type code. Always “CP”.
 */
@property (nonatomic, nonnull, readonly) NSString *documentCode;
/**
 * Added in version 6.16.0
 *
 * The full MRZ text as it appears on a document.
 */
@property (nonatomic, nonnull, readonly) NSString *capturedMrz;
/**
 * Added in version 6.16.0
 *
 * The ISO code of the issuing jurisdiction.
 */
@property (nonatomic, nonnull, readonly) NSString *passportIssuerIso;
/**
 * Added in version 6.16.0
 *
 * The passport number of the document holder.
 */
@property (nonatomic, nonnull, readonly) NSString *passportNumber;
/**
 * Added in version 6.16.0
 *
 * The expiry date of the holder’s passport.
 */
@property (nonatomic, nonnull, readonly) SDCDateResult *passportDateOfExpiry;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
