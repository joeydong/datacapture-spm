/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCProfessionalDrivingPermit;
@class SDCVehicleRestriction;

/**
 * Added in version 6.8.0
 *
 * Information obtained from the PDF417 barcode present on the back of a South Africa Driver’s License specific to this kind of document.
 */
NS_SWIFT_NAME(SouthAfricaDLBarcodeResult)
SDC_EXPORTED_SYMBOL
@interface SDCSouthAfricaDLBarcodeResult : NSObject

/**
 * Added in version 6.8.0
 *
 * The version of the barcode.
 */
@property (nonatomic, readonly) NSInteger version;
/**
 * Added in version 6.8.0
 *
 * The name of the country, where the Driver’s License was issued.
 */
@property (nonatomic, nonnull, readonly) NSString *licenseCountryOfIssue;
/**
 * Added in version 6.8.0
 *
 * The personal ID number of this Driver’s License holder.
 */
@property (nonatomic, nonnull, readonly) NSString *personalIdNumber;
/**
 * Added in version 6.8.0
 *
 * The kind of personal ID number used - “02” means the number of the South Africa ID card.
 */
@property (nonatomic, nonnull, readonly) NSString *personalIdNumberType;
/**
 * Added in version 6.8.0
 *
 * Identifies if this document has been duplicated, starting from 1.
 */
@property (nonatomic, readonly) NSInteger documentCopy;
/**
 * Added in version 6.8.0
 *
 * The categories of motor vehicles that the holder of this License is permitted to drive.
 */
@property (nonatomic, nonnull, readonly) NSArray<SDCVehicleRestriction *> *vehicleRestrictions;
/**
 * Added in version 6.8.0
 *
 * Whether the holder of this License is allowed to transport goods, dangerous goods or passengers for an income.
 */
@property (nonatomic, nullable, readonly) SDCProfessionalDrivingPermit *professionalDrivingPermit;
/**
 * Added in version 6.8.0
 *
 * The driver restriction codes. Empty array means that there is no restrictions. Number 1 stands for glasses/contact lenses. Number 2 stands for artificial limbs.
 */
@property (nonatomic, nonnull, readonly) NSArray<NSNumber *> *driverRestrictionCodes;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
