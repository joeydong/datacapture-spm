/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.14.0
 *
 * Information obtained from the Machine Readable Zone (MRZ) of an Exit-Entry Permit for Travelling to and from Hong Kong and Macau (往来港澳通行证) or an Exit-Entry Permit for Travelling to and from Taiwan (往来台灣通行证) issued by the People’s Republic of China.
 */
NS_SWIFT_NAME(ChinaExitEntryPermitMrzResult)
SDC_EXPORTED_SYMBOL
@interface SDCChinaExitEntryPermitMrzResult : NSObject

/**
 * Added in version 6.14.0
 *
 * The document type code. One of the following values:
 *
 *   • CS - indicates an Exit-Entry Permit for Travelling to and from Hong Kong and Macau (往来港澳通行证);
 *
 *   • CD - indicates an Exit-Entry Permit for Travelling to and from Taiwan (往来台灣通行证).
 */
@property (nonatomic, nonnull, readonly) NSString *documentCode;
/**
 * Added in version 6.14.0
 *
 * The full MRZ text as it appears on a document.
 */
@property (nonatomic, nonnull, readonly) NSString *capturedMrz;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end
NS_ASSUME_NONNULL_END
