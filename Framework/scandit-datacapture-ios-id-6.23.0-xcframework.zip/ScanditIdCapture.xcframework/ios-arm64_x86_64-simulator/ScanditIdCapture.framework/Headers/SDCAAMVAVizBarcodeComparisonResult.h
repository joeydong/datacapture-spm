/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

@class SDCStringComparisonCheck;
@class SDCDateComparisonCheck;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.11.0
 *
 * The result of an AAMVA-compliant personal identification document verification conducted by SDCAAMVAVizBarcodeComparisonVerifier.
 */
NS_SWIFT_NAME(AAMVAVizBarcodeComparisonResult)
SDC_EXPORTED_SYMBOL
@interface SDCAAMVAVizBarcodeComparisonResult : NSObject

/**
 * Added in version 6.11.0
 *
 * Whether all the checks conducted by the verifier passed. Only the check that were run count, so YES is returned even if some of the checks were skipped.
 */
@property (nonatomic, readonly) BOOL checksPassed;
/**
 * Added in version 6.11.0
 *
 * The human-readable result of the verification.
 */
@property (nonatomic, nonnull, readonly) NSString *resultDescription;
/**
 * Added in version 6.11.0
 *
 * Whether the issuing countries extracted from both sources of the data are the same.
 */
@property (nonatomic, readonly) SDCStringComparisonCheck *issuingCountryISOMatch;
/**
 * Added in version 6.11.0
 *
 * Whether the issuing jurisdictions (for example: an issuing state, territory or federal district for USA, or an issuing province or territory for Canada) extracted from both sources of the data are the same.
 */
@property (nonatomic, readonly) SDCStringComparisonCheck *issuingJurisdictionISOMatch;
/**
 * Added in version 6.11.0
 *
 * Whether the document numbers extracted from both sources of the data match. This check may permit minor data divergence, to compensate, for example, for a single character misread by OCR.
 */
@property (nonatomic, readonly) SDCStringComparisonCheck *documentNumbersMatch;
/**
 * Added in version 6.11.0
 *
 * Whether the holder’s full names extracted from both sources of the data match. This check may permit minor data divergence, to compensate, for example, for a single character misread by OCR.
 */
@property (nonatomic, readonly) SDCStringComparisonCheck *fullNamesMatch;
/**
 * Added in version 6.11.0
 *
 * Whether the holder’s dates of birth extracted from both sources of the data are the same.
 */
@property (nonatomic, readonly) SDCDateComparisonCheck *datesOfBirthMatch;
/**
 * Added in version 6.11.0
 *
 * Whether the document’s dates of expiry extracted from both sources of the data are the same.
 */
@property (nonatomic, readonly) SDCDateComparisonCheck *datesOfExpirationMatch;
/**
 * Added in version 6.11.0
 *
 * Whether the document’s dates of issue extracted from both sources of the data are the same.
 */
@property (nonatomic, readonly) SDCDateComparisonCheck *datesOfIssueMatch;

/**
 * Added in version 6.22.0
 *
 * Jpeg encoded image with mismatched fields highlighted. Returns nil when no mismatch found, or the license does not permit this feature.
 */
@property (nonatomic, nullable, readonly) UIImage *frontMismatchImage;

/**
 * Added in version 6.12.0
 *
 * Returns the JSON representation of this object.
 */
@property (nonatomic, readonly) NSString *JSONString;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end
NS_ASSUME_NONNULL_END
