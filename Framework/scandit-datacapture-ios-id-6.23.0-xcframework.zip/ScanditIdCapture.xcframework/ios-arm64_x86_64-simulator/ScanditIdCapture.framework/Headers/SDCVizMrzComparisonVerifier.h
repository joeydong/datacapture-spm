/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCDataCaptureContext.h>

@class SDCVizMrzComparisonResult;
@class SDCCapturedId;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.18.0
 *
 * Verifies a personal identification document with a VIZ and an MRZ by comparing the human-readable data of the document with the data encoded in the MRZ, and signals any suspicious differences.
 *
 * The verifier may permit minor data divergence, to compensate, for example, for a single character misread by OCR. Thus, while it automatically detects many fraudulent documents, a failed check does not necessary mean that the document is invalid. It is up to the user to subject such documents to additional scrutiny.
 *
 * Create the verifier and initialize SDCIdCapture with the following settings:
 *
 * @code
 * let dataCaptureContext = DataCaptureContext(licenseKey: "-- ENTER YOUR SCANDIT LICENSE KEY HERE --")
 *
 * let verifier = VizMrzComparisonVerifier()
 *
 * let settings = IdCaptureSettings()
 * settings.supportedDocuments = [ .idCardVIZ ]
 * settings.supportedSides = .frontAndBack
 *
 * let idCapture = IdCapture(context: dataCaptureContext, settings: settings)
 * @endcode
 *
 * Then proceed to capture the front side & the back side of a document as usual. After you capture the back side and receive the combined result for both sides, you may run the verifier as follows:
 *
 * @code
 * func idCapture(_ idCapture: IdCapture, didCaptureIn session: IdCaptureSession, frameData: FrameData) {
 *     guard let capturedId = session.newlyCapturedId,
 *         let vizResult = capturedId.vizResult,
 *         let _ = capturedId.mrzResult,
 *         vizResult.capturedSides == .frontAndBack
 *     else { return }
 *
 *     let result = verifier.verify(capturedId)
 *
 *     if result.checksPassed {
 *         // Nothing suspicious was detected.
 *     } else {
 *         // You may inspect the results of individual checks, if you wish:
 *         if (result.datesOfBirthMatch.checkResult == .failed) {
 *           // The holder’s date of birth from the front side does not match the one encoded in the MRZ.
 *         }
 *     }
 * }
 * @endcode
 *
 * The return value allows you to query both the overall result of the verification and the results of individual checks. See SDCVizMrzComparisonResult for details.
 */
NS_SWIFT_NAME(VizMrzComparisonVerifier)
SDC_EXPORTED_SYMBOL
@interface SDCVizMrzComparisonVerifier : NSObject
+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
/**
 * Added in version 6.22.0
 *
 * Creates a new instance of this verifier.
 */
+ (instancetype)verifierWithContext:(SDCDataCaptureContext *)context NS_SWIFT_NAME(init(context:));
/**
 * Added in version 6.18.0
 *
 * Creates a new instance of this verifier.
 */
+ (nonnull instancetype)verifier DEPRECATED_MSG_ATTRIBUTE("Use verifierWithContext: instead");
/**
 * Added in version 6.18.0
 *
 * Compares the human-readable data of the document with the data encoded in the MRZ, and signals any suspicious differences.
 */
- (nonnull SDCVizMrzComparisonResult *)verify:(nonnull SDCCapturedId *)capturedId;
@end
NS_ASSUME_NONNULL_END
