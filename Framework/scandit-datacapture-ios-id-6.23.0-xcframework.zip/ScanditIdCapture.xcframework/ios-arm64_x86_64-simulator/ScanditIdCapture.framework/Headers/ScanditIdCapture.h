/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double ScanditIdCaptureVersionNumber;

FOUNDATION_EXPORT const unsigned char ScanditIdCaptureVersionString[];

#import <ScanditCaptureCore/ScanditCaptureCore.h>
#import <ScanditIdCapture/SDCAAMVABarcodeResult.h>
#import <ScanditIdCapture/SDCAAMVABarcodeVerificationResult.h>
#import <ScanditIdCapture/SDCAAMVABarcodeVerifier.h>
#import <ScanditIdCapture/SDCAAMVAVizBarcodeComparisonResult.h>
#import <ScanditIdCapture/SDCAAMVAVizBarcodeComparisonVerifier.h>
#import <ScanditIdCapture/SDCApecBusinessTravelCardMrzResult.h>
#import <ScanditIdCapture/SDCArgentinaIdBarcodeResult.h>
#import <ScanditIdCapture/SDCCapturedId.h>
#import <ScanditIdCapture/SDCChinaExitEntryPermitMrzResult.h>
#import <ScanditIdCapture/SDCChinaMainlandTravelPermitMrzResult.h>
#import <ScanditIdCapture/SDCChinaOneWayPermitBackMrzResult.h>
#import <ScanditIdCapture/SDCChinaOneWayPermitFrontMrzResult.h>
#import <ScanditIdCapture/SDCColombiaDlBarcodeResult.h>
#import <ScanditIdCapture/SDCColombiaIdBarcodeResult.h>
#import <ScanditIdCapture/SDCCommonAccessCardBarcodeResult.h>
#import <ScanditIdCapture/SDCComparisonCheck.h>
#import <ScanditIdCapture/SDCComparisonCheckResult.h>
#import <ScanditIdCapture/SDCDateComparisonCheck.h>
#import <ScanditIdCapture/SDCDateResult.h>
#import <ScanditIdCapture/SDCIdAnonymizationMode.h>
#import <ScanditIdCapture/SDCIdCapture.h>
#import <ScanditIdCapture/SDCIdCaptureDeserializer.h>
#import <ScanditIdCapture/SDCIdCaptureFeedback.h>
#import <ScanditIdCapture/SDCIdCaptureOverlay.h>
#import <ScanditIdCapture/SDCIdCaptureSession.h>
#import <ScanditIdCapture/SDCIdCaptureSettings.h>
#import <ScanditIdCapture/SDCIdDocumentType.h>
#import <ScanditIdCapture/SDCLocalizedOnlyId.h>
#import <ScanditIdCapture/SDCMrzResult.h>
#import <ScanditIdCapture/SDCProfessionalDrivingPermit.h>
#import <ScanditIdCapture/SDCRejectedId.h>
#import <ScanditIdCapture/SDCSouthAfricaDLBarcodeResult.h>
#import <ScanditIdCapture/SDCSouthAfricaIdBarcodeResult.h>
#import <ScanditIdCapture/SDCStringComparisonCheck.h>
#import <ScanditIdCapture/SDCSupportedSides.h>
#import <ScanditIdCapture/SDCUsUniformedServicesBarcodeResult.h>
#import <ScanditIdCapture/SDCUsVisaVizResult.h>
#import <ScanditIdCapture/SDCVehicleRestriction.h>
#import <ScanditIdCapture/SDCVizMrzComparisonCheck.h>
#import <ScanditIdCapture/SDCVizMrzComparisonCheckResult.h>
#import <ScanditIdCapture/SDCVizMrzComparisonResult.h>
#import <ScanditIdCapture/SDCVizMrzComparisonVerifier.h>
#import <ScanditIdCapture/SDCVizMrzDateComparisonCheck.h>
#import <ScanditIdCapture/SDCVizMrzStringComparisonCheck.h>
#import <ScanditIdCapture/SDCVizResult.h>

