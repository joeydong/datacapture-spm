/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.18.0
 *
 * Information obtained from the PDF417 barcode present on the front of a Common Access Card.
 */
NS_SWIFT_NAME(CommonAccessCardBarcodeResult)
SDC_EXPORTED_SYMBOL
@interface SDCCommonAccessCardBarcodeResult : NSObject

/**
 * Added in version 6.18.0
 *
 * The document’s version.
 */
@property (nonatomic, nonnull, readonly) NSString *version;
/**
 * Added in version 6.18.0
 *
 * The holder’s designator identifier (usually, the cardholder’s SSN).
 */
@property (nonatomic, readonly) NSInteger personDesignatorDocument;
/**
 * Added in version 6.18.0
 *
 * The card’s person designator type code.
 */
@property (nonatomic, nonnull, readonly) NSString *personDesignatorTypeCode;
/**
 * Added in version 6.18.0
 *
 * The holder’s DEERS-assigned numeric identifier.
 */
@property (nonatomic, nonnull, readonly) NSString *ediPersonIdentifier;
/**
 * Added in version 6.18.0
 *
 * The holder’s personnel category code.
 */
@property (nonatomic, nonnull, readonly) NSString *personnelCategoryCode;
/**
 * Added in version 6.18.0
 *
 * The holder’s branch of service.
 */
@property (nonatomic, nonnull, readonly) NSString *branchOfService;
/**
 * Added in version 6.18.0
 *
 * The holder’s personnel entitlement condition type code.
 */
@property (nonatomic, nonnull, readonly) NSString *personnelEntitlementConditionType;
/**
 * Added in version 6.18.0
 *
 * The holder’s rank.
 */
@property (nonatomic, nonnull, readonly) NSString *rank;
/**
 * Added in version 6.18.0
 *
 * The holder’s pay plan code.
 */
@property (nonatomic, nonnull, readonly) NSString *payPlanCode;
/**
 * Added in version 6.18.0
 *
 * The holder’s pay plan grade code.
 */
@property (nonatomic, nonnull, readonly) NSString *payPlanGradeCode;
/**
 * Added in version 6.18.0
 *
 * Machine-generated code that is used for security purposes.
 */
@property (nonatomic, nonnull, readonly) NSString *cardInstanceIdentifier;
/**
 * Added in version 6.18.0
 *
 * The holder’s middle name initial.
 */
@property (nonatomic, nonnull, readonly) NSString *personMiddleInitial;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
