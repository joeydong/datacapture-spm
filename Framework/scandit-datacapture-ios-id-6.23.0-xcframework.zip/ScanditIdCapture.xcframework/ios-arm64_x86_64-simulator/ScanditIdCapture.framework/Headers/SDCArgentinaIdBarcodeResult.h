/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.8.0
 *
 * Information obtained from the PDF417 barcode present on the front of an Argentina ID (Documento Nacional de Identidad) specific to this kind of document.
 */
NS_SWIFT_NAME(ArgentinaIdBarcodeResult)
SDC_EXPORTED_SYMBOL
@interface SDCArgentinaIdBarcodeResult : NSObject

/**
 * Added in version 6.8.0
 *
 * Identifies if the document has been duplicated. “A” for the original document that the holder received. The subsequent copies (received for example due to theft, loss or destruction of the previous document) are marked as “B”, “C” and so on.
 */
@property (nonatomic, nonnull, readonly) NSString *documentCopy;
/**
 * Added in version 6.8.0
 *
 * The personal ID Number of the document holder.
 */
@property (nonatomic, nonnull, readonly) NSString *personalIdNumber;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
