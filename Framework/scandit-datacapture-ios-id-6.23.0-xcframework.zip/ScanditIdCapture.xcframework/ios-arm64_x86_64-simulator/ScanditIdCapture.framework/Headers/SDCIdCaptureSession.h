/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

@class SDCCapturedId;
@class SDCLocalizedOnlyId;
@class SDCRejectedId;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.2.0
 *
 * The ID capture session is responsible for keeping the SDCCapturedId data.
 *
 * The capture session should only be accessed from within idCapture:didCaptureInSession:frameData: to which it is provided as an argument. It is not safe to be accessed from anywhere else since it may be concurrently modified. References to the individual captured IDs can be kept and processed later as they are not further modified.
 */
NS_SWIFT_NAME(IdCaptureSession)
SDC_EXPORTED_SYMBOL
@interface SDCIdCaptureSession : NSObject

/**
 * Added in version 6.2.0
 *
 * Parsed data from a document recognized in the last frame, if any.
 */
@property (nonatomic, nullable, readonly) SDCCapturedId *newlyCapturedId;
/**
 * Added in version 6.10.0
 *
 * An information about a document or its part localized in the last frame, if any. A document or its part is considered localized when it’s detected in a frame, but its data is not yet extracted.
 */
@property (nonatomic, nullable, readonly) SDCLocalizedOnlyId *newlyLocalizedOnlyId;
/**
 * Added in version 6.10.0
 *
 * An information about a document or its part recognized in a frame, but rejected. A document is rejected if (a) it’s not enabled in the settings (see SDCIdCaptureSettings.supportedDocuments), (b) it’s a barcode of a correct symbology or a Machine Readable Zone (MRZ), but the data is encoded in an unexpected/incorrect format.
 */
@property (nonatomic, nullable, readonly) SDCRejectedId *newlyRejectedId;
/**
 * Added in version 6.2.0
 *
 * The identifier of the current frame sequence.
 *
 * As long as there is no interruptions of frames coming from the camera, the frameSequenceId will stay the same.
 */
@property (nonatomic, readonly) NSInteger frameSequenceId;
/**
 * Added in version 6.6.0
 *
 * Returns the JSON representation of the ID Capture session.
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
