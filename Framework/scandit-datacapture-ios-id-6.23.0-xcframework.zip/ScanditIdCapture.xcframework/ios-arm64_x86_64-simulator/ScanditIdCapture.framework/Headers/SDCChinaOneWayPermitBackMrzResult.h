/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.16.0
 *
 * Information obtained from the Machine Readable Zone (MRZ) present on the back of a One-Way Permit to Hong Kong/Macau issued by the People’s Republic of China.
 */
NS_SWIFT_NAME(ChinaOneWayPermitBackMrzResult)
SDC_EXPORTED_SYMBOL
@interface SDCChinaOneWayPermitBackMrzResult : NSObject

/**
 * Added in version 6.16.0
 *
 * The document type code. Always “QS”.
 */
@property (nonatomic, nonnull, readonly) NSString *documentCode;
/**
 * Added in version 6.16.0
 *
 * Indicates whether the first or the last names are truncated. For more information please refer to the official
 * specification.
 */
@property (nonatomic, readonly) BOOL namesAreTruncated;
/**
 * Added in version 6.16.0
 *
 * The full MRZ text as it appears on a document.
 */
@property (nonatomic, nonnull, readonly) NSString *capturedMrz;
/**
 * Added in version 6.16.0
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end
NS_ASSUME_NONNULL_END
