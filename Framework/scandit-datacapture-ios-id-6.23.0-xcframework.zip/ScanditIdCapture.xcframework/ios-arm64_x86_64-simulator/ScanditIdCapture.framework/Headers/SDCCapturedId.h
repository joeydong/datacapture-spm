/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>
#import <ScanditIdCapture/SDCIdDocumentType.h>

NS_ASSUME_NONNULL_BEGIN

@class UIImage;
@class SDCAAMVABarcodeResult;
@class SDCArgentinaIdBarcodeResult;
@class SDCDateResult;
@class SDCMrzResult;
@class SDCUsUniformedServicesBarcodeResult;
@class SDCVizResult;
@class SDCColombiaDlBarcodeResult;
@class SDCColombiaIdBarcodeResult;
@class SDCSouthAfricaDLBarcodeResult;
@class SDCSouthAfricaIdBarcodeResult;
@class SDCCommonAccessCardBarcodeResult;
@class SDCChinaMainlandTravelPermitMrzResult;
@class SDCChinaExitEntryPermitMrzResult;
@class SDCChinaOneWayPermitBackMrzResult;
@class SDCChinaOneWayPermitFrontMrzResult;
@class SDCApecBusinessTravelCardMrzResult;
@class SDCUsVisaVizResult;

/**
 * Added in version 6.2.0
 *
 * Possible image types that can be extracted from a recognized document.
 */
typedef NS_CLOSED_ENUM(NSUInteger, SDCIdImageType) {
/**
     * Added in version 6.2.0
     *
     * A photo of the document’s holder.
     */
    SDCIdImageTypeFace,
/**
     * Added in version 6.6.0
     *
     * An image of the front side of a document.
     */
    SDCIdImageTypeIdFront,
/**
     * Added in version 6.6.0
     *
     * An image of the back side of a document.
     */
    SDCIdImageTypeIdBack,
} NS_SWIFT_NAME(IdImageType);

/**
 * Added in version 6.5.0
 *
 * Enum value kept in SDCCapturedId.capturedResultType. It indicates which nonnull results SDCCapturedId holds.
 */
typedef NS_OPTIONS(NSUInteger, SDCCapturedResultType) {
/**
     * Added in version 6.5.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.mrzResult.
     */
    SDCCapturedResultTypeMrzResult = 1 << 0,
/**
     * Added in version 6.5.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.aamvaBarcodeResult.
     */
    SDCCapturedResultTypeAAMVABarcodeResult = 1 << 1,
/**
     * Added in version 6.5.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.usUniformedServicesBarcodeResult.
     */
    SDCCapturedResultTypeUSUniformedServicesBarcodeResult = 1 << 2,
/**
     * Added in version 6.5.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.vizResult.
     */
    SDCCapturedResultTypeVizResult = 1 << 3,
/**
     * Added in version 6.8.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.colombiaIdBarcodeResult.
     */
    SDCCapturedResultTypeColombiaIdBarcodeResult = 1 << 4,
/**
     * Added in version 6.8.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.argentinaIdBarcodeResult.
     */
    SDCCapturedResultTypeArgentinaIdBarcodeResult = 1 << 5,
/**
     * Added in version 6.8.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.southAfricaDLBarcodeResult.
     */
    SDCCapturedResultTypeSouthAfricaDLBarcodeResult = 1 << 6,
/**
     * Added in version 6.8.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.southAfricaIdBarcodeResult.
     */
    SDCCapturedResultTypeSouthAfricaIdBarcodeResult = 1 << 7,
/**
     * Added in version 6.13.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.colombiaDlBarcodeResult.
     */
    SDCCapturedResultTypeColombiaDlBarcodeResult = 1 << 8,
/**
     * Added in version 6.14.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.chinaMainlandTravelPermitMrzResult.
     */
    SDCCapturedResultTypeChinaMainlandTravelPermitMrzResult = 1 << 9,
/**
     * Added in version 6.14.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.chinaExitEntryPermitMrzResult.
     */
    SDCCapturedResultTypeChinaExitEntryPermitMrzResult = 1 << 10,
/**
     * Added in version 6.16.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.chinaOneWayPermitBackMrzResult.
     */
    SDCCapturedResultTypeChinaOneWayPermitBackMrzResult = 1 << 11,
/**
     * Added in version 6.16.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.chinaOneWayPermitFrontMrzResult.
     */
    SDCCapturedResultTypeChinaOneWayPermitFrontMrzResult = 1 << 12,
/**
     * Added in version 6.16.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.apecBusinessTravelCardMrzResult.
     */
    SDCCapturedResultTypeApecBusinessTravelCardMrzResult = 1 << 13,
/**
     * Added in version 6.18.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.commonAccessCardBarcodeResult.
     */
    SDCCapturedResultTypeCommonAccessCardBarcodeResult = 1 << 14,
/**
     * Added in version 6.18.0
     *
     * The SDCCapturedId contains a nonnull SDCCapturedId.usVisaVizResult.
     */
    SDCCapturedResultTypeUsVisaVizResult = 1 << 15,
} NS_SWIFT_NAME(CapturedResultType);

/**
 * Added in version 6.5.0
 */
typedef NS_CLOSED_ENUM(NSUInteger, SDCDocumentType) {
/**
     * Added in version 6.5.0
     *
     * A document of unrecognized type.
     */
    SDCDocumentTypeNone,
/**
     * Added in version 6.5.0
     *
     * A Consular ID Card.
     */
    SDCDocumentTypeConsularId,
/**
     * Added in version 6.5.0
     *
     * A Driver’s License Card (for example an AAMVA Driver License).
     */
    SDCDocumentTypeDrivingLicense,
/**
     * Added in version 6.5.0
     *
     * A British Colombia Driver’s License and Services Card.
     */
    SDCDocumentTypeDrivingLicensePublicServicesCard,
/**
     * Added in version 6.5.0
     *
     * A Singapore Employment Pass.
     */
    SDCDocumentTypeEmploymentPass,
/**
     * Added in version 6.5.0
     *
     * A Singapore FIN (Foreign Identification Number) Card.
     */
    SDCDocumentTypeFinCard,
/**
     * Added in version 6.5.0
     *
     * An ID Card.
     */
    SDCDocumentTypeId,
/**
     * Added in version 6.5.0
     *
     * A Multipurpose ID Card.
     */
    SDCDocumentTypeMultipurposeId,
/**
     * Added in version 6.5.0
     *
     * A Malaysia ID Card (MyKad)
     */
    SDCDocumentTypeMyKAD,
/**
     * Added in version 6.5.0
     *
     * A Malaysia MyKid Card.
     */
    SDCDocumentTypeMyKID,
/**
     * Added in version 6.5.0
     *
     * A Malaysia MyPR Card.
     */
    SDCDocumentTypeMyPR,
/**
     * Added in version 6.5.0
     *
     * A Malaysia MyTentera Card.
     */
    SDCDocumentTypeMyTentera,
/**
     * Added in version 6.5.0
     *
     * An India Pan Card.
     */
    SDCDocumentTypePanCard,
/**
     * Added in version 6.5.0
     *
     * A Philippines Professional ID Card.
     */
    SDCDocumentTypeProfessionalId,
/**
     * Added in version 6.5.0
     *
     * A British Colombia Services Card.
     */
    SDCDocumentTypePublicServicesCard,
/**
     * Added in version 6.5.0
     *
     * A Residence Permit.
     */
    SDCDocumentTypeResidencePermit,
/**
     * Added in version 6.5.0
     *
     * A Resident ID Card.
     */
    SDCDocumentTypeResidentId,
/**
     * Added in version 6.5.0
     *
     * A Temporary Residence Permit.
     */
    SDCDocumentTypeTemporaryResidencePermit,
/**
     * Added in version 6.5.0
     *
     * A Voter ID Card.
     */
    SDCDocumentTypeVoterId,
/**
     * Added in version 6.5.0
     *
     * A Work Permit.
     */
    SDCDocumentTypeWorkPermit,
/**
     * Added in version 6.5.0
     *
     * A Malaysia IKad Card.
     */
    SDCDocumentTypeIKAD NS_SWIFT_NAME(iKAD),
/**
     * Added in version 6.5.0
     *
     * A Military ID card (for example a US Uniformed Services ID).
     */
    SDCDocumentTypeMilitaryId,
/**
     * Added in version 6.5.0
     *
     * A Malaysia MyKas Card.
     */
    SDCDocumentTypeMyKAS,
/**
     * Added in version 6.5.0
     *
     * A Social Security Card.
     */
    SDCDocumentTypeSocialSecurityCard,
/**
     * Added in version 6.5.0
     *
     * A Health Insurance Card.
     */
    SDCDocumentTypeHealthInsuranceCard,
/**
     * Added in version 6.5.0
     *
     * A Passport.
     */
    SDCDocumentTypePassport,
/**
     * Added in version 6.12.0
     *
     * A Diplomatic Passport.
     */
    SDCDocumentTypeDiplomaticPassport,
/**
     * Added in version 6.12.0
     *
     * A Service Passport.
     */
    SDCDocumentTypeServicePassport,
/**
     * Added in version 6.12.0
     *
     * A Temporary Passport.
     */
    SDCDocumentTypeTemporaryPassport,
/**
     * Added in version 6.5.0
     *
     * A Visa.
     */
    SDCDocumentTypeVisa,
/**
     * Added in version 6.6.0
     *
     * A Singapore S Pass.
     */
    SDCDocumentTypeSPass NS_SWIFT_NAME(sPass),
/**
     * Added in version 6.7.0
     *
     * An Address Card.
     */
    SDCDocumentTypeAddressCard,
/**
     * Added in version 6.7.0
     *
     * An Alien ID Card.
     */
    SDCDocumentTypeAlienId,
/**
     * Added in version 6.7.0
     *
     * An Alien Passport.
     */
    SDCDocumentTypeAlienPassport,
/**
     * Added in version 6.7.0
     *
     * An US Permanent Resident Card (commonly known as a Green Card).
     */
    SDCDocumentTypeGreenCard,
/**
     * Added in version 6.7.0
     *
     * A Minors ID Card.
     */
    SDCDocumentTypeMinorsId,
/**
     * Added in version 6.7.0
     *
     * A Postal ID Card.
     */
    SDCDocumentTypePostalId,
/**
     * Added in version 6.7.0
     *
     * A Professional Driver’s License.
     */
    SDCDocumentTypeProfessionalDL,
/**
     * Added in version 6.7.0
     *
     * A Tax ID Card.
     */
    SDCDocumentTypeTaxId,
/**
     * Added in version 6.7.0
     *
     * A Weapon Permit.
     */
    SDCDocumentTypeWeaponPermit,
/**
     * Added in version 6.8.0
     *
     * A US Border Crossing Card.
     */
    SDCDocumentTypeBorderCrossingCard,
/**
     * Added in version 6.8.0
     *
     * A Driver Card.
     */
    SDCDocumentTypeDriverCard,
/**
     * Added in version 6.8.0
     *
     * A US Global Entry Card.
     */
    SDCDocumentTypeGlobalEntryCard,
/**
     * Added in version 6.8.0
     *
     * A Malaysia MyPolis Card.
     */
    SDCDocumentTypeMyPolis,
/**
     * Added in version 6.8.0
     *
     * A US Nexus Card.
     */
    SDCDocumentTypeNexusCard,
/**
     * Added in version 6.8.0
     *
     * A Passport Card.
     */
    SDCDocumentTypePassportCard,
/**
     * Added in version 6.8.0
     *
     * A South Australia Proof of Age Card.
     */
    SDCDocumentTypeProofOfAgeCard,
/**
     * Added in version 6.8.0
     *
     * A Refugee ID.
     */
    SDCDocumentTypeRefugeeId,
/**
     * Added in version 6.8.0
     *
     * A Tribal ID.
     */
    SDCDocumentTypeTribalId,
/**
     * Added in version 6.8.0
     *
     * A Veteran ID.
     */
    SDCDocumentTypeVeteranId,
/**
     * Added in version 6.11.0
     *
     * A Citizenship Certificate.
     */
    SDCDocumentTypeCitizenshipCertificate,
/**
     * Added in version 6.14.0
     *
     * A Japanese My Number Card.
     */
    SDCDocumentTypeMyNumberCard,
/**
     * Added in version 6.15.0
     *
     * A Minors Passport.
     */
    SDCDocumentTypeMinorsPassport,
/**
     * Added in version 6.15.0
     *
     * A Minor Public Services Card.
     */
    SDCDocumentTypeMinorsPublicServicesCard,
/**
     * Added in version 6.16.0
     *
     * An APEC (Asia-Pacific Economic Cooperation) Business Travel Card.
     */
    SDCDocumentTypeApecBusinessTravelCard,
/**
     * Added in version 6.19.0
     *
     * Driver Privilege Card for non-US citizens.
     */
    SDCDocumentTypeDrivingPrivilegeCard,
/**
     * Added in version 6.21.0
     *
     * A Asylum Request.
     */
    SDCDocumentTypeAsylumRequest,
/**
     * Added in version 6.21.0
     *
     * A Driver Qualification Card.
     */
    SDCDocumentTypeDriverQualificationCard,
/**
     * Added in version 6.21.0
     *
     * A Provisional Driver’s License.
     */
    SDCDocumentTypeProvisionalDl,
/**
     * Added in version 6.21.0
     *
     * A Refugee Passport.
     */
    SDCDocumentTypeRefugeePassport,
/**
     * Added in version 6.21.0
     *
     * A Special ID.
     */
    SDCDocumentTypeSpecialId,
/**
     * Added in version 6.21.0
     *
     * A Uniformed Services ID.
     */
    SDCDocumentTypeUniformedServicesId,
/**
     * Added in version 6.22.0
     *
     * A Immigrant Visa.
     */
    SDCDocumentTypeImmigrantVisa,
/**
     * Added in version 6.22.0
     *
     * A Consular Voter ID.
     */
    SDCDocumentTypeConsularVoterId,
/**
     * Added in version 6.22.0
     *
     * A TWIC Card.
     */
    SDCDocumentTypeTwicCard
} NS_SWIFT_NAME(DocumentType);

/**
 * Added in version 6.6.0
 *
 * A class that represents a result of a document scan. This class contains the captured information that is commonly present in all the documents, like the name or the date of birth of the holder.
 *
 * The class can be cast to a concrete implementation using capturedResultType.
 */
NS_SWIFT_NAME(CapturedId)
SDC_EXPORTED_SYMBOL
@interface SDCCapturedId : NSObject
/**
 * Added in version 6.6.0
 *
 * The first name of the document holder. Separated by spaces if more than one name is present. Characters can be all uppercase for document types which don’t capitalize names (for example names encoded in ICAO Machine Readable Zones).
 */
@property (nonatomic, nullable, readonly) NSString *firstName;
/**
 * Added in version 6.6.0
 *
 * The last name of the document holder. Separated by spaces if more than one name is present. Characters can be all uppercase for document types which don’t capitalize names (for example names encoded in ICAO Machine Readable Zones).
 */
@property (nonatomic, nullable, readonly) NSString *lastName;
/**
 * Added in version 6.6.0
 *
 * The full name of the document holder. Characters can be all uppercase for document types which don’t capitalize names (for example names encoded in ICAO Machine Readable Zones).
 */
@property (nonatomic, nonnull, readonly) NSString *fullName;
/**
 * Added in version 6.6.0
 *
 * The sex of the document holder.
 */
@property (nonatomic, nullable, readonly) NSString *sex;
/**
 * Added in version 6.6.0
 *
 * The date of birth of the document holder. If the document doesn’t provide two first digits of the year then the date of birth is always set to be earlier than or equal to the scan date. For example if the year of scanning is 2021 and the document returns that the year of birth is 14 then the returned year is set to 2014. However if the document returns that the year of birth is 24 then the returned year is set to 1924.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *dateOfBirth;
/**
 * Added in version 6.6.0
 *
 * The nationality of the document holder represented by a three-letter code (Alpha-3 codes specified in ISO 3166-1).
 */
@property (nonatomic, nullable, readonly) NSString *nationality;
/**
 * Added in version 6.6.0
 *
 * The address of the document holder.
 */
@property (nonatomic, nullable, readonly) NSString *address;
/**
 * Added in version 6.6.0
 *
 * The captured result type. Consult the documentation for more information about it.
 *
 * Deprecated since version 6.11: Replaced by capturedResultTypes.
 */
@property (nonatomic, readonly) SDCCapturedResultType capturedResultType DEPRECATED_MSG_ATTRIBUTE("Use capturedResultTypes instead.");
/**
 * Added in version 6.11.0
 *
 * The captured result types. Guaranteed to contain at least one element. Consult the documentation for more information about it.
 */
@property (nonatomic, readonly) SDCCapturedResultType capturedResultTypes;
/**
 * Added in version 6.6.0
 *
 * The document type. Consult the documentation for more information about it.
 */
@property (nonatomic, readonly) SDCDocumentType documentType;
/**
 * Added in version 6.6.0
 *
 * The ISO (Alpha-3 code) abbreviation of the issuing country of the document.
 */
@property (nonatomic, nullable, readonly) NSString *issuingCountryISO;
/**
 * Added in version 6.6.0
 *
 * A human readable text identifying the country that issues the document.
 */
@property (nonatomic, nullable, readonly) NSString *issuingCountry;
/**
 * Added in version 6.6.0
 *
 * The document number.
 *
 * If SDCIdCaptureSettings.anonymizationMode is enabled for the field results, the returned value might be nil for certain documents.
 */
@property (nonatomic, nullable, readonly) NSString *documentNumber;
/**
 * Added in version 6.19.0
 *
 * If SDCIdCaptureSettings.anonymizationMode is enabled for the field results, the returned value might be nil for certain documents.
 *
 * If SDCIdCaptureSettings.anonymizationMode is enabled for the field results, the returned value might be nil for certain documents.
 */
@property (nonatomic, nullable, readonly) NSString *documentAdditionalNumber;
/**
 * Added in version 6.6.0
 *
 * The date of expiry of the document.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *dateOfExpiry;
/**
 * Added in version 6.16.0
 *
 * Whether this document is expired. Calculated by comparing the document’s expiration date with the current local date. When converted to boolean returns YES if the document is expired and NO if it’s not expired, or if it never expires. nil is returned if the value of this property could not be determined - for example if the date of expiry is not present, or if the date of expiry couldn’t be captured. Please note that the system time is used for computation of this field so users of the device are capable of changing the result of the field by changing the system time.
 */
@property (nonatomic, nullable, readonly) NSNumber *isExpired;
/**
 * Added in version 6.6.0
 *
 * The date of issue of the document. Please note that some documents may specify the exact date of issue, while other the month and the year only.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *dateOfIssue;
/**
 * Added in version 6.16.0
 *
 * The age of the document holder. Calculated as the difference in full years between the birth date and the current local date. If nil is returned it means that the full birth date is not available. The returned value depends on the device date. The same document may result in different values for devices with different dates (e.g. in different time zones, or with a date set manually by the user).
 */
@property (nonatomic, nullable, readonly) NSNumber *age;
/**
 * Added in version 6.6.0
 *
 * Returns the JSON representation of the captured id.
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

/**
 * Added in version 6.6.0
 *
 * The additional information extracted from a documents or its part intended to be read by humans (for example Visual Inspection Zone (VIZ) of a Machine-Readable Travel Document (MRTD)). This property is guaranteed to be non-nil when capturedResultType is SDCCapturedResultTypeVizResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCVizResult *vizResult;
/**
 * Added in version 6.6.0
 *
 * The additional information extracted from the Machine Readable Zone (MRZ) of a Machine Readable Travel Document (MRTD). This property is guaranteed to be non-nil when capturedResultType is SDCCapturedResultTypeMrzResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCMrzResult *mrzResult;
/**
 * Added in version 6.6.0
 *
 * The additional information extracted from a barcode on a document that follows the American Association of Motor Vehicle Administrators (AAMVA) specification. This property is guaranteed to be non-nil when capturedResultType is SDCCapturedResultTypeAAMVABarcodeResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCAAMVABarcodeResult *aamvaBarcodeResult;
/**
 * Added in version 6.6.0
 *
 * The additional information extracted from a barcode on a United States Uniformed Services Identification card. This property is guaranteed to be non-nil when capturedResultType is SDCCapturedResultTypeUSUniformedServicesBarcodeResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCUsUniformedServicesBarcodeResult *usUniformedServicesBarcodeResult;
/**
 * Added in version 6.13.0
 *
 * The additional information extracted from a barcode on a Colombia Driver’s License (Licencia de Conducción). This property is guaranteed to be non-nil when capturedResultTypes is SDCCapturedResultTypeColombiaDlBarcodeResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCColombiaDlBarcodeResult *colombiaDlBarcodeResult;
/**
 * Added in version 6.8.0
 *
 * The additional information extracted from a barcode on a Colombia ID (Cédula de Ciudadanía). This property is guaranteed to be non-nil when capturedResultType is SDCCapturedResultTypeColombiaIdBarcodeResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCColombiaIdBarcodeResult *colombiaIdBarcodeResult;
/**
 * Added in version 6.8.0
 *
 * The additional information extracted from a barcode on a Argentina ID (Documento Nacional de Identidad). This property is guaranteed to be non-nil when capturedResultType is SDCCapturedResultTypeArgentinaIdBarcodeResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCArgentinaIdBarcodeResult *argentinaIdBarcodeResult;
/**
 * Added in version 6.8.0
 *
 * The additional information extracted from a barcode on a South Africa Driver’s License. This property is guaranteed to be non-nil when capturedResultType is SDCCapturedResultTypeSouthAfricaDLBarcodeResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCSouthAfricaDLBarcodeResult *southAfricaDLBarcodeResult;
/**
 * Added in version 6.8.0
 *
 * The additional information extracted from a barcode on a South Africa identity card (Smart ID Card). This property is guaranteed to be non-nil when capturedResultType is SDCCapturedResultTypeSouthAfricaIdBarcodeResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCSouthAfricaIdBarcodeResult *southAfricaIdBarcodeResult;
/**
 * Added in version 6.18.0
 */
@property (nonatomic, nullable, readonly) SDCCommonAccessCardBarcodeResult *commonAccessCardBarcodeResult;
/**
 * Added in version 6.14.0
 *
 * The additional information extracted from a barcode on a China Mainland Travel Permit. This property is guaranteed to be non-nil when capturedResultTypes is SDCCapturedResultTypeChinaMainlandTravelPermitMrzResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCChinaMainlandTravelPermitMrzResult *chinaMainlandTravelPermitMrzResult;
/**
 * Added in version 6.14.0
 *
 * The additional information extracted from the Machine Readable Zone (MRZ) present on an Exit-Entry Permit for Travelling to and from Hong Kong and Macau (往来港澳通行证) or an Exit-Entry Permit for Travelling to and from Taiwan (往来台灣通行证) issued by People’s Republic of China. This property is guaranteed to be non-nil when capturedResultTypes is SDCCapturedResultTypeChinaMainlandTravelPermitMrzResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCChinaExitEntryPermitMrzResult *chinaExitEntryPermitMrzResult;
/**
 * Added in version 6.16.0
 *
 * The additional information extracted from the Machine Readable Zone (MRZ) present on the back of a One-Way Permit to Hong Kong/Macau issued by People’s Republic of China. This property is guaranteed to be non-nil when capturedResultTypes is SDCCapturedResultTypeChinaOneWayPermitBackMrzResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCChinaOneWayPermitBackMrzResult *chinaOneWayPermitBackMrzResult;
/**
 * Added in version 6.16.0
 *
 * The additional information extracted from the Machine Readable Zone (MRZ) present on the front of a One-Way Permit to Hong Kong/Macau issued by People’s Republic of China. This property is guaranteed to be non-nil when capturedResultTypes is SDCCapturedResultTypeChinaOneWayPermitFrontMrzResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCChinaOneWayPermitFrontMrzResult *chinaOneWayPermitFrontMrzResult;
/**
 * Added in version 6.16.0
 *
 * The additional information extracted from the Machine Readable Zone (MRZ) present on the back of an APEC (Asia-Pacific Economic Cooperation) Business Travel Card. This property is guaranteed to be non-nil when capturedResultTypes is SDCCapturedResultTypeApecBusinessTravelCardMrzResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCApecBusinessTravelCardMrzResult *apecBusinessTravelCardMrzResult;
/**
 * Added in version 6.18.0
 *
 * The additional information extracted from the US Visa. This property is guaranteed to be non-nil when capturedResultTypes is SDCCapturedResultTypeUsVisaVizResult, and is nil otherwise.
 */
@property (nonatomic, nullable, readonly) SDCUsVisaVizResult *usVisaVizResult;

/**
 * Added in version 6.6.0
 *
 * Gets a bitmap for an image type.
 */
- (nullable UIImage *)idImageOfType:(SDCIdImageType)idImageType;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
/**
 * Added in version 6.12.0
 *
 * Creates a captured id from the passed JSON string.
 */
+ (instancetype)capturedIdFromJSONString:(NSString *)JSONString NS_SWIFT_NAME(init(jsonString:));

@end

NS_ASSUME_NONNULL_END
