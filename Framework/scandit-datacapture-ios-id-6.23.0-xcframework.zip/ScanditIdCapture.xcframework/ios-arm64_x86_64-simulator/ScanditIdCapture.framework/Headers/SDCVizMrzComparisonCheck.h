/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditIdCapture/SDCVizMrzComparisonCheckResult.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.18.0
 *
 * A comparison done by SDCVizMrzComparisonVerifier of a single piece of data from a personal identification document with a VIZ and an MRZ.
 */
NS_SWIFT_NAME(ComparisonCheck)
@protocol SDCVizMrzComparisonCheck <NSObject>

/**
 * Added in version 6.18.0
 *
 * Whether any suspicious divergence in data is detected.
 */
@property (nonatomic, readonly) SDCVizMrzComparisonCheckResult checkResult;
/**
 * Added in version 6.18.0
 *
 * The human-readable result of the comparison.
 */
@property (nonatomic, nonnull, readonly) NSString *resultDescription;

@end
NS_ASSUME_NONNULL_END
