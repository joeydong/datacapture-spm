/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCDateResult;

/**
 * Added in version 6.6.0
 *
 * Information obtained from the PDF417 barcode of an AAMVA-compliant personal identification document.
 *
 * The ID Capture supports all versions of the Driver License and Identification Standard published by AAMVA (personal identification documents used, for example, in the US and Canada). Some pre-Standard barcodes (documents issued before 2000) may also be successfully parsed, if their format doesn’t differ much from the version 1 of the Standard. Encrypted barcodes issued in the US State of Georgia before 2012 are currently not supported.
 *
 * The encoding of card holder information has changed significantly between revisions of the DL/ID specification (most notably between 2000 codes and later codes) and the same piece of information is encoded differently, depending on the version.
 *
 * In addition, the implementations of the specification vary strongly between jurisdictions, as many of them don’t implement the specifications correctly. If you are experiencing trouble when scanning certain DL/ID cards, we suggest to contact the Scandit team to resolve the issues.
 */
NS_SWIFT_NAME(AAMVABarcodeResult)
SDC_EXPORTED_SYMBOL
@interface SDCAAMVABarcodeResult : NSObject

/**
 * Added in version 6.5.0
 *
 * The version level of the PDF417 barcode format. See the AAMVA DL/ID Card Design Standard for more details.
 */
@property (nonatomic, readonly) NSInteger aamvaVersion;
/**
 * Added in version 6.5.0
 *
 * The jurisdiction specific version number of the implementation.
 */
@property (nonatomic, readonly) NSInteger jurisdictionVersion;
/**
 * Added in version 6.5.0
 *
 * The Issuer Identification Number which uniquely identifies the issuing jurisdiction.
 */
@property (nonatomic, nonnull, readonly) NSString *IIN;
/**
 * Added in version 6.5.0
 *
 * A human readable name of the issuing jurisdiction (for example: an issuing state, territory or federal district for USA, or an issuing province or territory for Canada).
 */
@property (nonatomic, nonnull, readonly) NSString *issuingJurisdiction;
/**
 * Added in version 6.5.0
 *
 * The ISO code of the issuing jurisdiction (for example: an issuing state, territory or federal district for USA, or an issuing province or territory for Canada).
 *
 * @remark The returned value will only contain the jurisdiction specific code: for instance for California the returned value would be “CA” and not “US-CA”.
 */
@property (nonatomic, nonnull, readonly) NSString *issuingJurisdictionISO;
/**
 * Added in version 6.5.0
 *
 * The eye color of the card holder.
 */
@property (nonatomic, nullable, readonly) NSString *eyeColor;
/**
 * Added in version 6.5.0
 *
 * The hair color of the card holder.
 */
@property (nonatomic, nullable, readonly) NSString *hairColor;
/**
 * Added in version 6.5.0
 *
 * The height of the card holder in inches.
 */
@property (nonatomic, nullable, readonly) NSNumber *heightInch;
/**
 * Added in version 6.5.0
 *
 * The height of the card holder in centimeters.
 */
@property (nonatomic, nullable, readonly) NSNumber *heightCm;
/**
 * Added in version 6.5.0
 *
 * Thw weight of the card holder in pounds.
 */
@property (nonatomic, nullable, readonly) NSNumber *weightLbs;
/**
 * Added in version 6.5.0
 *
 * The weight of the card holder in kilograms.
 */
@property (nonatomic, nullable, readonly) NSNumber *weightKg;
/**
 * Added in version 6.5.0
 *
 * The place of birth of the card holder.
 */
@property (nonatomic, nullable, readonly) NSString *placeOfBirth;
/**
 * Added in version 6.5.0
 *
 * The race of the card holder.
 */
@property (nonatomic, nullable, readonly) NSString *race;
/**
 * Added in version 6.5.0
 *
 * The document discriminator number.
 */
@property (nonatomic, nullable, readonly) NSString *documentDiscriminatorNumber;
/**
 * Added in version 6.5.0
 *
 * The vehicle classification.
 */
@property (nonatomic, nullable, readonly) NSString *vehicleClass;
/**
 * Added in version 6.5.0
 *
 * The restriction code.
 */
@property (nonatomic, nullable, readonly) NSString *restrictionsCode;
/**
 * Added in version 6.5.0
 *
 * The endorsement code.
 */
@property (nonatomic, nullable, readonly) NSString *endorsementsCode;
/**
 * Added in version 6.5.0
 *
 * Card revision date.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *cardRevisionDate;
/**
 * Added in version 6.5.0
 *
 * The middle name of the card holder.
 */
@property (nonatomic, nullable, readonly) NSString *middleName;
/**
 * Added in version 6.21.0
 *
 * The first name of the document holder. It doesn’t contain middle name(s).
 */
@property (nonatomic, nullable, readonly) NSString *firstNameWithoutMiddleName;
/**
 * Added in version 6.5.0
 *
 * The name suffix of the card holder.
 */
@property (nonatomic, nullable, readonly) NSString *driverNameSuffix;
/**
 * Added in version 6.5.0
 *
 * The name prefix of the card holder.
 */
@property (nonatomic, nullable, readonly) NSString *driverNamePrefix;
/**
 * Added in version 6.5.0
 *
 * The last name truncation. A code that indicates whether a field has been truncated (‘T’), has not been truncated (‘N’), unknown whether truncated (‘U’), or the information is not present in the document (nil).
 */
@property (nonatomic, nullable, readonly) NSString *lastNameTruncation;
/**
 * Added in version 6.5.0
 *
 * The first name truncation. A code that indicates whether a field has been truncated (‘T’), has not been truncated (‘N’), unknown whether truncated (‘U’), or the information is not present in the document (nil).
 */
@property (nonatomic, nullable, readonly) NSString *firstNameTruncation;
/**
 * Added in version 6.5.0
 *
 * The middle name truncation. A code that indicates whether a field has been truncated (‘T’), has not been truncated (‘N’), unknown whether truncated (‘U’), or the information is not present in the document (nil).
 */
@property (nonatomic, nullable, readonly) NSString *middleNameTruncation;
/**
 * Added in version 6.5.0
 *
 * Other family name by which cardholder is known.
 */
@property (nonatomic, nullable, readonly) NSString *aliasFamilyName;
/**
 * Added in version 6.5.0
 *
 * Other given name by which cardholder is known.
 */
@property (nonatomic, nullable, readonly) NSString *aliasGivenName;
/**
 * Added in version 6.5.0
 *
 * Other suffix name by which cardholder is known.
 */
@property (nonatomic, nullable, readonly) NSString *aliasSuffixName;
/**
 * Added in version 6.16.0
 *
 * Returns true if the document is a Real ID.
 */
@property (nonatomic, readonly) BOOL isRealId;
/**
 * Added in version 6.6.0
 *
 * The mappings between all the barcode data element IDs and their values. The keys of this collection are the element IDs as defined in the AAMVA Driver License/Identification specification. For example, the specification defines a data element “Customer First Name” with the ID “DAC”. Therefore if a scanned barcode contains a string “DACMICHAEL”, then this collection will contain a mapping with “DAC” as the key and “MICHAEL” as the value. This collection contains all the data elements of the barcode - including those that are exposed also explicitly as fields of this class.
 *
 * See Barcode Data Elements for all the possible keys and their meaning.
 */
@property (nonatomic, nonnull, readonly) NSDictionary<NSString *, NSString *> *barcodeDataElements;
/**
 * Added in version 6.6.0
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
