/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>

@class SDCDateResult;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.5.0
 *
 * ID Capture supports parsing Uniformed Services Identification Cards that are encoded in PDF417 barcodes. Both Sponsor and Dependant documents are supported (versions 1, 2 and 3). For the complete documentation of the standard please refer to US Uniformed Services ID.
 */
NS_SWIFT_NAME(UsUniformedServicesBarcodeResult)
SDC_EXPORTED_SYMBOL
@interface SDCUsUniformedServicesBarcodeResult : NSObject

/**
 * Added in version 6.5.0
 *
 * The version of the document. It can be 1, 2 or 3.
 */
@property (nonatomic, readonly) NSInteger version;
/**
 * Added in version 6.5.0
 *
 * Indicates whether the card holder is sponsor or dependent.
 */
@property (nonatomic, nonnull, readonly) NSString *sponsorFlag;
/**
 * Added in version 6.5.0
 *
 * The person’s designator identifier (usually, the cardholder’s SSN).
 */
@property (nonatomic, readonly) NSInteger personDesignatorDocument;
/**
 * Added in version 6.5.0
 *
 * Used to distinguish among sponsors who have the same SSN.
 */
@property (nonatomic, readonly) NSInteger familySequenceNumber;
/**
 * Added in version 6.5.0
 *
 * The code of the relationship of a dependent to his or her sponsor.
 */
@property (nonatomic, readonly) NSInteger deersDependentSuffixCode;
/**
 * Added in version 6.5.0
 *
 * The description of the relationship of a dependent to his or her sponsor.
 */
@property (nonatomic, nonnull, readonly) NSString *deersDependentSuffixDescription;
/**
 * Added in version 6.5.0
 *
 * The holder’s height in inches.
 */
@property (nonatomic, readonly) NSInteger height;
/**
 * Added in version 6.5.0
 *
 * The holder’s weight in pounds.
 */
@property (nonatomic, readonly) NSInteger weight;
/**
 * Added in version 6.5.0
 *
 * The holder’s hair color.
 */
@property (nonatomic, nonnull, readonly) NSString *hairColor;
/**
 * Added in version 6.5.0
 *
 * The holder’s eye color.
 */
@property (nonatomic, nonnull, readonly) NSString *eyeColor;
/**
 * Added in version 6.5.0
 *
 * The code of the direct care privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *directCareFlagCode;
/**
 * Added in version 6.5.0
 *
 * The description of the direct care privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *directCareFlagDescription;
/**
 * Added in version 6.5.0
 *
 * The code of the civilian health care privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *civilianHealthCareFlagCode;
/**
 * Added in version 6.5.0
 *
 * The description of the civilian health care privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *civilianHealthCareFlagDescription;
/**
 * Added in version 6.5.0
 *
 * The code of the commissary privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *commissaryFlagCode;
/**
 * Added in version 6.5.0
 *
 * The description of the commissary privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *commissaryFlagDescription;
/**
 * Added in version 6.5.0
 *
 * The code of the Morale, Welfare & Recreation (MWR) privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *mwrFlagCode;
/**
 * Added in version 6.5.0
 *
 * The description of the Morale, Welfare & Recreation (MWR) privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *mwrFlagDescription;
/**
 * Added in version 6.5.0
 *
 * The code of the exchange privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *exchangeFlagCode;
/**
 * Added in version 6.5.0
 *
 * The description of the exchange privilege/benefit flag.
 */
@property (nonatomic, nonnull, readonly) NSString *exchangeFlagDescription;
/**
 * Added in version 6.5.0
 *
 * The CHAMPUS effective date.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *champusEffectiveDate;
/**
 * Added in version 6.5.0
 *
 * The CHAMPUS expiration date.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *champusExpiryDate;
/**
 * Added in version 6.5.0
 *
 * The form number.
 */
@property (nonatomic, nonnull, readonly) NSString *formNumber;
/**
 * Added in version 6.5.0
 *
 * The card security code.
 */
@property (nonatomic, nonnull, readonly) NSString *securityCode;
/**
 * Added in version 6.5.0
 *
 * The service code.
 */
@property (nonatomic, nonnull, readonly) NSString *serviceCode;
/**
 * Added in version 6.5.0
 *
 * The status of the sponsor.
 */
@property (nonatomic, nonnull, readonly) NSString *statusCode;
/**
 * Added in version 6.5.0
 *
 * The description of the the code of the status of the sponsor.
 */
@property (nonatomic, nonnull, readonly) NSString *statusCodeDescription;
/**
 * Added in version 6.5.0
 *
 * An organization with which the sponsor is affiliated.
 */
@property (nonatomic, nonnull, readonly) NSString *branchOfService;
/**
 * Added in version 6.5.0
 *
 * The rank of the sponsor.
 */
@property (nonatomic, nonnull, readonly) NSString *rank;
/**
 * Added in version 6.5.0
 *
 * The pay grade of the sponsor. Available since version 2.
 */
@property (nonatomic, nullable, readonly) NSString *payGrade;
/**
 * Added in version 6.5.0
 *
 * The name of the sponsor.
 */
@property (nonatomic, nullable, readonly) NSString *sponsorName;
/**
 * Added in version 6.5.0
 *
 * The sponsor’s designator identifier (Usually, the cardholder’s SSN).
 */
@property (nonatomic, nullable, readonly) NSNumber *sponsorPersonDesignatorIdentifier;
/**
 * Added in version 6.5.0
 *
 * The code of the dependent’s relationship to the sponsor.
 */
@property (nonatomic, nullable, readonly) NSString *relationshipCode;
/**
 * Added in version 6.5.0
 *
 * The description of the dependent’s relationship to the sponsor.
 */
@property (nonatomic, nullable, readonly) NSString *relationshipDescription;
/**
 * Added in version 6.5.0
 *
 * The sponsor’s appropriate Geneva Convention Category.
 */
@property (nonatomic, nullable, readonly) NSString *genevaConventionCategory;
/**
 * Added in version 6.5.0
 *
 * The sponsor’s blood type.
 */
@property (nonatomic, nullable, readonly) NSString *bloodType;
/**
 * Added in version 6.9.0
 *
 * A compressed version of the photograph printed on the front of the card.
 */
@property (nonatomic, nullable, readonly) NSString *JPEGData;
/**
 * Added in version 6.6.0
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
