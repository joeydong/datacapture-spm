/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditIdCapture/SDCVizMrzComparisonCheck.h>

@class SDCDateResult;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.18.0
 *
 * The result of the comparison of a SDCDateResult field performed by SDCVizMrzComparisonVerifier. Check SDCVizMrzComparisonCheck for more information.
 */
NS_SWIFT_NAME(VizMrzDateComparisonCheck)
SDC_EXPORTED_SYMBOL
@interface SDCVizMrzDateComparisonCheck : NSObject <SDCVizMrzComparisonCheck>

/**
 * Added in version 6.18.0
 *
 * The SDCDateResult field extracted from the human-readable zone of a personal identification document with a VIZ and an MRZ.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *vizValue;
/**
 * Added in version 6.18.0
 *
 * The SDCDateResult field extracted from the MRZ present at the front or the back side of a personal identification document with a VIZ and an MRZ.
 */
@property (nonatomic, nullable, readonly) SDCDateResult *mrzValue;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
