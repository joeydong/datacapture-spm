/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/ScanditCaptureCore.h>
#import <ScanditIdCapture/SDCComparisonCheckResult.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 6.11.0
 *
 * A comparison done by SDCAAMVAVizBarcodeComparisonVerifier of a single piece of data from an AAMVA-compliant personal identification document.
 */
NS_SWIFT_NAME(ComparisonCheck)
@protocol SDCComparisonCheck <NSObject>

/**
 * Added in version 6.11.0
 *
 * Whether any suspicious divergence in data is detected.
 */
@property (nonatomic, readonly) SDCComparisonCheckResult checkResult;
/**
 * Added in version 6.11.0
 *
 * The human-readable result of the comparison.
 */
@property (nonatomic, nonnull, readonly) NSString *resultDescription;

@end
NS_ASSUME_NONNULL_END
